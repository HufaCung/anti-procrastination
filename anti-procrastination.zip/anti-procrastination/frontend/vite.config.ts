import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

const proxy = { '/api': process.env.TINYDO_API_URL || 'http://localhost:3001' };

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { dedupe: ['react', 'react-dom'] },
  server: { proxy },
  preview: { proxy },
  test: { include: ['src/**/*.test.ts'], environment: 'node' },
});

import type {
  FocusSession,
  Project,
  Task,
  TaskPriority,
  TimerPreset,
  TimerPresetId,
} from '../types/workspace';

export const TIMER_PRESETS: TimerPreset[] = [
  { id: 'pomodoro', label: 'Pomodoro', minutes: 25, isBreak: false },
  { id: 'deep', label: 'Deep Work', minutes: 50, isBreak: false },
  { id: 'short_break', label: 'Short Break', minutes: 5, isBreak: true },
  { id: 'long_break', label: 'Long Break', minutes: 15, isBreak: true },
];

export function formatDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function addDaysToDateKey(dateKey: string, deltaDays: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  const dt = new Date(y, m - 1, d + deltaDays);
  return formatDateKey(dt);
}

export function formatTimerClock(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const minutes = Math.floor(safe / 60);
  const seconds = safe % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export function formatMinutesLabel(minutes: number): string {
  const safe = Math.max(0, Math.round(minutes));
  if (safe < 60) return `${safe}m`;
  const hrs = Math.floor(safe / 60);
  const mins = safe % 60;
  return mins === 0 ? `${hrs}h` : `${hrs}h ${mins}m`;
}

export function formatTime12h(time24: string): string {
  if (!time24 || !time24.includes(':')) return time24;
  const [hStr, mStr] = time24.split(':');
  const h = Number(hStr);
  const m = Number(mStr);
  if (Number.isNaN(h) || Number.isNaN(m)) return time24;
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${String(hour12).padStart(2, '0')}:${String(m).padStart(2, '0')} ${period}`;
}

export function getPresetDurationSeconds(presetId: TimerPresetId, customMinutes: number): number {
  if (presetId === 'custom') {
    return Math.max(1, Math.min(180, Math.round(customMinutes))) * 60;
  }
  const found = TIMER_PRESETS.find((p) => p.id === presetId);
  return (found ? found.minutes : 25) * 60;
}

export interface DashboardStats {
  todayTotalTasks: number;
  todayCompletedTasks: number;
  todayPlannedMinutes: number;
  todayFocusedMinutes: number;
  todayRemainingMinutes: number;
  weeklyFocusedMinutes: number;
  weeklyGoalMinutes: number;
  weeklyGoalPercent: number;
  overallCompletionRate: number;
}

export function calculateDashboardStats(
  tasks: Task[],
  focusSessions: FocusSession[],
  todayKey: string,
  weeklyGoalMinutes = 600
): DashboardStats {
  const todayTasks = tasks.filter((t) => t.dueDate === todayKey);
  const todayCompletedTasks = todayTasks.filter((t) => t.completed).length;
  const todayPlannedMinutes = todayTasks.reduce((acc, t) => acc + t.estimatedMinutes, 0);
  const todayRemainingMinutes = todayTasks
    .filter((t) => !t.completed)
    .reduce((acc, t) => acc + Math.max(0, t.estimatedMinutes - t.loggedMinutes), 0);

  const todayFocusedMinutes = focusSessions
    .filter((s) => s.date === todayKey && s.mode !== 'short_break' && s.mode !== 'long_break')
    .reduce((acc, s) => acc + s.durationMinutes, 0);

  const weekStartKey = addDaysToDateKey(todayKey, -6);
  const weeklyFocusedMinutes = focusSessions
    .filter(
      (s) =>
        s.date >= weekStartKey &&
        s.date <= todayKey &&
        s.mode !== 'short_break' &&
        s.mode !== 'long_break'
    )
    .reduce((acc, s) => acc + s.durationMinutes, 0);

  const weeklyGoalPercent =
    weeklyGoalMinutes > 0
      ? Math.min(100, Math.round((weeklyFocusedMinutes / weeklyGoalMinutes) * 100))
      : 0;

  const totalTasks = tasks.length;
  const totalCompleted = tasks.filter((t) => t.completed).length;
  const overallCompletionRate =
    totalTasks > 0 ? Math.round((totalCompleted / totalTasks) * 100) : 0;

  return {
    todayTotalTasks: todayTasks.length,
    todayCompletedTasks,
    todayPlannedMinutes,
    todayFocusedMinutes,
    todayRemainingMinutes,
    weeklyFocusedMinutes,
    weeklyGoalMinutes,
    weeklyGoalPercent,
    overallCompletionRate,
  };
}

export interface ProjectProgress {
  totalTasks: number;
  completedTasks: number;
  completionPercent: number;
  estimatedMinutes: number;
  loggedMinutes: number;
}

export function calculateProjectProgress(
  projectId: string,
  tasks: Task[],
  focusSessions: FocusSession[]
): ProjectProgress {
  const projectTasks = tasks.filter((t) => t.projectId === projectId);
  const totalTasks = projectTasks.length;
  const completedTasks = projectTasks.filter((t) => t.completed).length;
  const completionPercent =
    totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const estimatedMinutes = projectTasks.reduce((sum, t) => sum + t.estimatedMinutes, 0);

  const sessionMinutes = focusSessions
    .filter((s) => s.projectId === projectId && s.mode !== 'short_break' && s.mode !== 'long_break')
    .reduce((sum, s) => sum + s.durationMinutes, 0);

  const loggedMinutes = Math.max(
    sessionMinutes,
    projectTasks.reduce((sum, t) => sum + t.loggedMinutes, 0)
  );

  return {
    totalTasks,
    completedTasks,
    completionPercent,
    estimatedMinutes,
    loggedMinutes,
  };
}

export interface TaskFilterOptions {
  search?: string;
  status?: 'all' | 'active' | 'completed';
  projectId?: string;
  dateKey?: string;
}

const PRIORITY_RANK: Record<TaskPriority, number> = {
  high: 0,
  medium: 1,
  low: 2,
};

export function filterAndSortTasks(tasks: Task[], options: TaskFilterOptions): Task[] {
  const query = (options.search || '').trim().toLowerCase();

  return tasks
    .filter((task) => {
      if (options.projectId && options.projectId !== 'all' && task.projectId !== options.projectId) {
        return false;
      }
      if (options.dateKey && task.dueDate !== options.dateKey) {
        return false;
      }
      if (options.status === 'active' && task.completed) return false;
      if (options.status === 'completed' && !task.completed) return false;
      if (query && !task.title.toLowerCase().includes(query)) return false;
      return true;
    })
    .sort((a, b) => {
      if (a.completed !== b.completed) return a.completed ? 1 : -1;
      if (a.dueDate !== b.dueDate) return a.dueDate.localeCompare(b.dueDate);
      if (a.scheduledTime !== b.scheduledTime) {
        return a.scheduledTime.localeCompare(b.scheduledTime);
      }
      return PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority];
    });
}

export interface CalendarCell {
  dateKey: string;
  dayNumber: number;
  inCurrentMonth: boolean;
  isToday: boolean;
  tasks: Task[];
}

export function buildCalendarMonth(
  year: number,
  monthIndex: number, // 0-11
  tasks: Task[],
  todayKey: string
): CalendarCell[] {
  const firstOfMonth = new Date(year, monthIndex, 1);
  const startDayOfWeek = firstOfMonth.getDay(); // 0=Sun
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();

  const tasksByDate = new Map<string, Task[]>();
  for (const task of tasks) {
    const existing = tasksByDate.get(task.dueDate);
    if (existing) {
      existing.push(task);
    } else {
      tasksByDate.set(task.dueDate, [task]);
    }
  }

  const cells: CalendarCell[] = [];
  const totalCells = Math.ceil((startDayOfWeek + daysInMonth) / 7) * 7;

  for (let i = 0; i < totalCells; i++) {
    const dayOffset = i - startDayOfWeek + 1;
    const cellDate = new Date(year, monthIndex, dayOffset);
    const dateKey = formatDateKey(cellDate);
    const inCurrentMonth = cellDate.getMonth() === monthIndex;
    cells.push({
      dateKey,
      dayNumber: cellDate.getDate(),
      inCurrentMonth,
      isToday: dateKey === todayKey,
      tasks: (tasksByDate.get(dateKey) || []).slice().sort((a, b) =>
        a.scheduledTime.localeCompare(b.scheduledTime)
      ),
    });
  }

  return cells;
}

export interface DailyFocusBar {
  dateKey: string;
  dayLabel: string;
  minutes: number;
  heightPercent: number;
}

export function buildWeeklyFocusBars(
  focusSessions: FocusSession[],
  todayKey: string
): DailyFocusBar[] {
  const days: { dateKey: string; dayLabel: string; minutes: number }[] = [];
  const weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  for (let offset = -6; offset <= 0; offset++) {
    const dateKey = addDaysToDateKey(todayKey, offset);
    const [y, m, d] = dateKey.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    const minutes = focusSessions
      .filter(
        (s) =>
          s.date === dateKey && s.mode !== 'short_break' && s.mode !== 'long_break'
      )
      .reduce((sum, s) => sum + s.durationMinutes, 0);

    days.push({
      dateKey,
      dayLabel: weekdayLabels[dt.getDay()],
      minutes,
    });
  }

  const maxMinutes = Math.max(60, ...days.map((d) => d.minutes));

  return days.map((d) => ({
    ...d,
    heightPercent: d.minutes === 0 ? 0 : Math.max(8, Math.round((d.minutes / maxMinutes) * 100)),
  }));
}

export function buildProjectTimeBreakdown(
  projects: Project[],
  tasks: Task[],
  focusSessions: FocusSession[]
): Array<{ project: Project; focusedMinutes: number; estimatedMinutes: number; sharePercent: number }> {
  const rows = projects.map((project) => {
    const prog = calculateProjectProgress(project.id, tasks, focusSessions);
    return {
      project,
      focusedMinutes: prog.loggedMinutes,
      estimatedMinutes: prog.estimatedMinutes,
    };
  });

  const totalFocused = rows.reduce((sum, r) => sum + r.focusedMinutes, 0);

  return rows
    .map((r) => ({
      ...r,
      sharePercent: totalFocused > 0 ? Math.round((r.focusedMinutes / totalFocused) * 100) : 0,
    }))
    .sort((a, b) => b.focusedMinutes - a.focusedMinutes);
}

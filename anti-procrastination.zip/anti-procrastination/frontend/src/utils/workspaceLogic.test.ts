import { test } from 'vitest';
import assert from 'node:assert/strict';
import {
  addDaysToDateKey,
  buildCalendarMonth,
  buildProjectTimeBreakdown,
  buildWeeklyFocusBars,
  calculateDashboardStats,
  calculateProjectProgress,
  filterAndSortTasks,
  formatMinutesLabel,
  formatTime12h,
  formatTimerClock,
  getPresetDurationSeconds,
} from './workspaceLogic';
import type { FocusSession, Project, Task } from '../types/workspace';

const TODAY = '2026-11-17';

const sampleProjects: Project[] = [
  {
    id: 'p1',
    name: 'TinyDo Redesign',
    description: 'Mobile-first UI',
    accentHex: '#4F46E5',
    dueDate: '2026-11-20',
    status: 'On Track',
    weeklyTargetMinutes: 300,
  },
  {
    id: 'p2',
    name: 'Marketing',
    description: 'Launch campaign',
    accentHex: '#D97706',
    dueDate: '2026-11-18',
    status: 'At Risk',
    weeklyTargetMinutes: 180,
  },
];

const sampleTasks: Task[] = [
  {
    id: 't1',
    title: 'Draft homepage outline',
    projectId: 'p1',
    dueDate: TODAY,
    scheduledTime: '09:00',
    estimatedMinutes: 45,
    loggedMinutes: 45,
    priority: 'high',
    completed: true,
    assigneeId: 'm1',
    createdAt: '2026-11-17T08:00:00Z',
  },
  {
    id: 't2',
    title: 'Fix navigation bug on mobile',
    projectId: 'p1',
    dueDate: TODAY,
    scheduledTime: '14:00',
    estimatedMinutes: 60,
    loggedMinutes: 15,
    priority: 'high',
    completed: false,
    assigneeId: 'm1',
    createdAt: '2026-11-17T08:30:00Z',
  },
  {
    id: 't3',
    title: 'Send weekly update email',
    projectId: 'p2',
    dueDate: '2026-11-18',
    scheduledTime: '10:30',
    estimatedMinutes: 30,
    loggedMinutes: 0,
    priority: 'medium',
    completed: false,
    assigneeId: 'm2',
    createdAt: '2026-11-17T09:00:00Z',
  },
];

const sampleSessions: FocusSession[] = [
  {
    id: 's1',
    taskId: 't1',
    projectId: 'p1',
    date: TODAY,
    durationMinutes: 45,
    mode: 'deep',
    completedAt: '2026-11-17T09:50:00Z',
  },
  {
    id: 's2',
    taskId: 't2',
    projectId: 'p1',
    date: addDaysToDateKey(TODAY, -1),
    durationMinutes: 30,
    mode: 'pomodoro',
    completedAt: '2026-11-16T15:00:00Z',
  },
  {
    id: 's3',
    taskId: null,
    projectId: null,
    date: TODAY,
    durationMinutes: 5,
    mode: 'short_break',
    completedAt: '2026-11-17T09:55:00Z',
  },
];

test('formatTimerClock and formatMinutesLabel format accurately', () => {
  assert.equal(formatTimerClock(1500), '25:00');
  assert.equal(formatTimerClock(65), '01:05');
  assert.equal(formatTimerClock(-5), '00:00');
  assert.equal(formatMinutesLabel(45), '45m');
  assert.equal(formatMinutesLabel(60), '1h');
  assert.equal(formatMinutesLabel(135), '2h 15m');
  assert.equal(formatTime12h('09:00'), '09:00 AM');
  assert.equal(formatTime12h('14:30'), '02:30 PM');
  assert.equal(getPresetDurationSeconds('pomodoro', 10), 1500);
  assert.equal(getPresetDurationSeconds('custom', 40), 2400);
});

test('calculateDashboardStats computes today tasks, planned/remaining time, and excludes breaks', () => {
  const stats = calculateDashboardStats(sampleTasks, sampleSessions, TODAY, 300);
  assert.equal(stats.todayTotalTasks, 2);
  assert.equal(stats.todayCompletedTasks, 1);
  assert.equal(stats.todayPlannedMinutes, 105);
  assert.equal(stats.todayFocusedMinutes, 45);
  assert.equal(stats.todayRemainingMinutes, 45); // t2: 60 - 15 = 45
  assert.equal(stats.weeklyFocusedMinutes, 75); // 45 + 30 (break excluded)
  assert.equal(stats.weeklyGoalPercent, 25); // 75 / 300
  assert.equal(stats.overallCompletionRate, 33); // 1 / 3
});

test('calculateProjectProgress aggregates completion and time', () => {
  const p1Stats = calculateProjectProgress('p1', sampleTasks, sampleSessions);
  assert.equal(p1Stats.totalTasks, 2);
  assert.equal(p1Stats.completedTasks, 1);
  assert.equal(p1Stats.completionPercent, 50);
  assert.equal(p1Stats.estimatedMinutes, 105);
  assert.equal(p1Stats.loggedMinutes, 75);
});

test('filterAndSortTasks filters by search, status, and project and orders active first', () => {
  const activeOnly = filterAndSortTasks(sampleTasks, { status: 'active' });
  assert.equal(activeOnly.length, 2);
  assert.equal(activeOnly[0].id, 't2');

  const searchRes = filterAndSortTasks(sampleTasks, { search: 'mobile' });
  assert.equal(searchRes.length, 1);
  assert.equal(searchRes[0].id, 't2');

  const projectTasks = filterAndSortTasks(sampleTasks, { projectId: 'p1' });
  assert.equal(projectTasks.length, 2);
  assert.equal(projectTasks[0].completed, false);
  assert.equal(projectTasks[1].completed, true);
});

test('buildCalendarMonth creates complete 7-column grid and attaches tasks to matching dates', () => {
  const cells = buildCalendarMonth(2026, 10, sampleTasks, TODAY); // November 2026
  assert.equal(cells.length % 7, 0);
  const todayCell = cells.find((c) => c.dateKey === TODAY);
  assert.ok(todayCell);
  assert.equal(todayCell.isToday, true);
  assert.equal(todayCell.dayNumber, 17);
  assert.equal(todayCell.tasks.length, 2);
});

test('buildWeeklyFocusBars and buildProjectTimeBreakdown compute chart arrays', () => {
  const bars = buildWeeklyFocusBars(sampleSessions, TODAY);
  assert.equal(bars.length, 7);
  assert.equal(bars[6].dateKey, TODAY);
  assert.equal(bars[6].minutes, 45);
  assert.equal(bars[5].minutes, 30);

  const breakdown = buildProjectTimeBreakdown(sampleProjects, sampleTasks, sampleSessions);
  assert.equal(breakdown.length, 2);
  assert.equal(breakdown[0].project.id, 'p1');
  assert.equal(breakdown[0].sharePercent, 100);
});

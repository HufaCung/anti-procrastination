import type { AppData } from '../../../backend/src/types';
import type { Workspace } from '../types/workspace';
import { formatDateKey } from '../utils/workspaceLogic';

export type Snapshot = { data: AppData; revision: number };

function scheduledTime(value?: string): string {
  const date = new Date(value ?? '');
  if (!Number.isFinite(date.getTime())) return '';
  return date.toTimeString().slice(0, 5);
}

export function fromServer(data: AppData): Workspace {
  const display = data.meta.dashboard;
  const focusSessions = data.sessions.map(session => ({
    id: session.id, taskId: session.taskId ?? null, projectId: session.projectId ?? null,
    date: display?.sessions[session.id]?.date ?? formatDateKey(new Date(session.endedAt)),
    durationMinutes: session.minutes,
    mode: display?.sessions[session.id]?.mode ?? 'pomodoro' as const,
    completedAt: session.endedAt,
  }));
  const minutesByTask = new Map<string, number>();
  for (const session of focusSessions) {
    if (session.taskId) minutesByTask.set(session.taskId, (minutesByTask.get(session.taskId) ?? 0) + session.durationMinutes);
  }
  return {
    projects: data.projects.map(project => ({
      id: project.id, name: project.name, accentHex: project.color, description: project.description ?? '',
      dueDate: project.dueDate,
      status: display?.projects[project.id]?.status ?? (project.completedAt ? 'Completed' : 'On Track'),
      weeklyTargetMinutes: display?.projects[project.id]?.weeklyTargetMinutes ?? 0,
    })),
    tasks: [...data.tasks].sort((a, b) => a.order - b.order).map(task => ({
      id: task.id, title: task.title, projectId: task.projectId, dueDate: task.dueDate ?? task.scheduledFor?.slice(0, 10) ?? '',
      scheduledTime: display?.tasks[task.id]?.scheduledTime ?? scheduledTime(task.scheduledFor), estimatedMinutes: task.estimateMin,
      loggedMinutes: display?.tasks[task.id]?.loggedMinutes ?? minutesByTask.get(task.id) ?? 0,
      priority: display?.tasks[task.id]?.priority ?? 'medium', completed: task.status === 'done', assigneeId: '', createdAt: task.createdAt,
    })),
    focusSessions,
  };
}

export function toServer(workspace: Workspace, base: AppData): AppData {
  const userId = base.meta.userId;
  const now = new Date().toISOString();
  const projects = new Map(base.projects.map(project => [project.id, project]));
  const tasks = new Map(base.tasks.map(task => [task.id, task]));
  const sessions = new Map(base.sessions.map(session => [session.id, session]));
  const workspaceTasks = new Map(workspace.tasks.map(task => [task.id, task]));
  const projectIds = new Set(workspace.projects.map(project => project.id));
  return {
    ...base,
    projects: workspace.projects.map(project => {
      const old = projects.get(project.id);
      return {
        ...old, id: project.id, userId, name: project.name, description: project.description,
        color: project.accentHex, dueDate: project.dueDate, createdAt: old?.createdAt ?? now,
        priority: old?.priority ?? 'medium',
        completedAt: project.status === 'Completed' ? old?.completedAt ?? now : undefined,
      };
    }),
    tasks: workspace.tasks.map((task, order) => {
      const old = tasks.get(task.id);
      const previousTime = base.meta.dashboard?.tasks[task.id]?.scheduledTime ?? scheduledTime(old?.scheduledFor);
      const previousDate = old?.dueDate ?? old?.scheduledFor?.slice(0, 10) ?? '';
      const scheduleChanged = task.scheduledTime !== previousTime || task.dueDate !== previousDate;
      const date = new Date(task.dueDate + 'T' + task.scheduledTime);
      const scheduledFor = scheduleChanged
        ? Number.isFinite(date.getTime()) ? date.toISOString() : undefined
        : old?.scheduledFor;
      return {
        ...old, id: task.id, userId, projectId: task.projectId, title: task.title, estimateMin: task.estimatedMinutes,
        section: old?.section ?? 'Inbox', scheduledFor,
        dueDate: task.dueDate === previousDate && old ? old.dueDate : task.dueDate || undefined,
        order, createdAt: task.createdAt,
        status: task.completed ? 'done' : old?.status === 'in_progress' ? 'in_progress' : 'todo',
        completedAt: task.completed ? old?.completedAt ?? now : undefined,
      };
    }),
    sessions: workspace.focusSessions.map(session => {
      const old = sessions.get(session.id);
      const task = session.taskId ? workspaceTasks.get(session.taskId) : undefined;
      return {
        id: session.id, userId, taskId: task?.id,
        projectId: task?.projectId ?? (session.projectId && projectIds.has(session.projectId) ? session.projectId : undefined),
        startedAt: old?.startedAt ?? new Date(Date.parse(session.completedAt) - session.durationMinutes * 60000).toISOString(),
        endedAt: session.completedAt, minutes: session.durationMinutes, completedTask: old?.completedTask ?? false,
      };
    }),
    meta: {
      ...base.meta,
      dashboard: {
        projects: Object.fromEntries(workspace.projects.map(({ id, status, weeklyTargetMinutes }) => [id, { status, weeklyTargetMinutes }])),
        tasks: Object.fromEntries(workspace.tasks.map(({ id, scheduledTime, loggedMinutes, priority }) => [id, { scheduledTime, loggedMinutes, priority }])),
        sessions: Object.fromEntries(workspace.focusSessions.map(({ id, mode, date }) => [id, { mode, date }])),
      },
    },
  };
}

/**
 * Authentication requests are verified by the backend. A local user copy keeps
 * the current profile and session available to the interface.
 */
import type { User } from './types';
import { KEYS, migrate, readJSON, usersRepo, writeJSON } from './storage';
import { api, setAuthToken } from './api';

export interface AuthSession {
  userId: string;
  createdAt: string;
  remember: boolean;
}

export const USERNAME_RE = /^\S{2,100}$/;

export const AUTH_ERRORS = {
  username: 'Enter a username of 2-100 characters without spaces.',
  password: 'Password must be at least 8 characters.',
  name: 'Enter your display name.',
  terms: 'Please accept the Terms to continue.',
  duplicate: 'An account with this username already exists.',
  invalid: 'Username or password is incorrect.',
} as const;

/** Password strength 0–4: +1 each for length ≥ 8, upper+lower, digit, symbol or length ≥ 14. */
export function passwordScore(pw: string): number {
  let s = 0;
  if (pw.length >= 8) s++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw) || pw.length >= 14) s++;
  return s;
}

function setSession(userId: string, remember: boolean) {
  const s: AuthSession = { userId, createdAt: new Date().toISOString(), remember };
  try {
    if (remember) {
      writeJSON(KEYS.session, s);
      sessionStorage.removeItem(KEYS.session);
    } else {
      localStorage.removeItem(KEYS.session);
      sessionStorage.setItem(KEYS.session, JSON.stringify(s));
    }
  } catch {
    /* storage unavailable */
  }
  return s;
}

export function getSession(): AuthSession | null {
  migrate();
  let s: AuthSession | null = null;
  try {
    s = readJSON<AuthSession | null>(KEYS.session, null) ?? readJSON<AuthSession | null>(KEYS.session, null, sessionStorage);
  } catch {
    s = null;
  }
  if (!s || !usersRepo.byId(s.userId)) return null;
  const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;
  if (Date.now() - new Date(s.createdAt).getTime() > THIRTY_DAYS) {
    try {
      localStorage.removeItem(KEYS.session);
      sessionStorage.removeItem(KEYS.session);
    } catch {
      /* ignore */
    }
    return null;
  }
  return s;
}

export function currentUser(): User | null {
  const s = getSession();
  return s ? usersRepo.byId(s.userId) ?? null : null;
}

export type AuthResult = { ok: true; user: User } | { ok: false; errors: Record<string, string> };

export async function signUp(input: { username: string; password: string; confirmPassword: string }): Promise<AuthResult> {
  const errors: Record<string, string> = {};
  if (!USERNAME_RE.test(input.username.trim())) errors.username = AUTH_ERRORS.username;
  if (input.password.length < 8 || input.password.length > 1024) errors.password = AUTH_ERRORS.password;
  if (input.password !== input.confirmPassword) errors.confirmPassword = 'Passwords do not match.';
  if (Object.keys(errors).length) return { ok: false, errors };
  const result = await api.signUp({ username: input.username.trim(), password: input.password });
  if (!result?.token || !result.user) return { ok: false, errors: { form: 'Could not create account. The username may already be in use, or the server may be unavailable.' } };
  const user = result.user;
  usersRepo.save(user);
  setSession(user.id, true);
  return { ok: true, user };
}

export async function logIn(input: { username: string; password: string; remember: boolean }): Promise<AuthResult> {
  const errors: Record<string, string> = {};
  if (!input.username.trim()) errors.username = AUTH_ERRORS.username;
  if (!input.password) errors.password = 'Enter your password.';
  if (Object.keys(errors).length) return { ok: false, errors };
  const res = await api.logIn({ username: input.username, password: input.password, remember: input.remember });
  if (!res?.user || !res.token) return { ok: false, errors: { form: AUTH_ERRORS.invalid } };
  const user = res.user;
  usersRepo.save(user);
  setSession(user.id, input.remember);
  return { ok: true, user };
}

export function logOut(): void {
  try {
    localStorage.removeItem(KEYS.session);
    sessionStorage.removeItem(KEYS.session);
    setAuthToken(null);
  } catch {
    /* ignore */
  }
}

export async function changePassword(userId: string, current: string, next: string): Promise<{ ok: boolean; error?: string }> {
  const user = usersRepo.byId(userId);
  if (!user) return { ok: false, error: 'Account not found.' };
  if (next.length < 8 || next.length > 1024) return { ok: false, error: AUTH_ERRORS.password };
  const result = await api.changePassword({ oldPassword: current, newPassword: next });
  if (!result?.user || !result.token) return { ok: false, error: result?.error ?? 'Could not update password. Please try again.' };
  usersRepo.save(result.user);
  return { ok: true };
}

export async function updateProfile(
  userId: string,
  patch: { name?: string; avatar?: string | null },
): Promise<{ ok: boolean; errors?: Record<string, string>; user?: User }> {
  const user = usersRepo.byId(userId);
  if (!user) return { ok: false, errors: { form: 'Account not found.' } };
  const errors: Record<string, string> = {};
  const name = patch.name ?? user.name;
  if (name.trim().length < 2) errors.name = AUTH_ERRORS.name;
  if (Object.keys(errors).length) return { ok: false, errors };
  const next: User = { ...user, name: name.trim() };
  if (patch.avatar === null) delete next.avatar;
  else if (patch.avatar) next.avatar = patch.avatar;
  const result = await api.updateProfile({ name: next.name, ...(patch.avatar !== undefined ? { avatar: patch.avatar } : {}) });
  if (!result?.user) return { ok: false, errors: { form: 'Could not save profile. Please try again.' } };
  usersRepo.save(result.user);
  return { ok: true, user: next };
}

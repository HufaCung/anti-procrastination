export type ViewId = 'dashboard' | 'projects' | 'calendar' | 'focus' | 'progress' | 'teams';

export type TaskPriority = 'high' | 'medium' | 'low';

export type TimerPresetId = 'pomodoro' | 'deep' | 'short_break' | 'long_break' | 'custom';

export interface Task {
  id: string;
  title: string;
  projectId: string;
  dueDate: string; // YYYY-MM-DD
  scheduledTime: string; // HH:mm
  estimatedMinutes: number;
  loggedMinutes: number;
  priority: TaskPriority;
  completed: boolean;
  assigneeId: string;
  createdAt: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  accentHex: string;
  dueDate: string; // YYYY-MM-DD
  status: 'On Track' | 'At Risk' | 'Completed';
  weeklyTargetMinutes: number;
}

export interface FocusSession {
  id: string;
  taskId: string | null;
  projectId: string | null;
  date: string; // YYYY-MM-DD
  durationMinutes: number;
  mode: TimerPresetId;
  completedAt: string; // ISO string
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  initials: string;
  weeklyCapacityMinutes: number;
  status: 'Focusing' | 'Available' | 'In Meeting';
}

export interface TimerPreset {
  id: TimerPresetId;
  label: string;
  minutes: number;
  isBreak: boolean;
}
export interface Workspace {
  tasks: Task[];
  projects: Project[];
  focusSessions: FocusSession[];
}

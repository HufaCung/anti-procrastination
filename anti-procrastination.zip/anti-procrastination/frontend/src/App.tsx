import React, { useCallback, useEffect, useMemo, useState } from 'react';
import type {
  FocusSession,
  Project,
  Task,
  TaskPriority,
  Workspace,
  TimerPresetId,
  ViewId,
} from './types/workspace';
import {
  calculateDashboardStats,
  formatDateKey,
  getPresetDurationSeconds,
} from './utils/workspaceLogic';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { DashboardView } from './components/DashboardView';
import { ProjectsView } from './components/ProjectsView';
import { CalendarView } from './components/CalendarView';
import { FocusView } from './components/FocusView';
import { AnalyticsView } from './components/AnalyticsView';
import { TeamsView } from './components/TeamsView';
import { TaskModal } from './components/TaskModal';
import { ProjectModal } from './components/ProjectModal';

export default function App({ workspace, onChange: setWorkspace, token, userId }: {
  workspace: Workspace;
  onChange: (update: (current: Workspace) => Workspace) => void;
  token: string;
  userId: string;
}) {
  const todayKey = formatDateKey(new Date());

  // Navigation & UI state
  const [currentView, setCurrentView] = useState<ViewId>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isFocusFullScreen, setIsFocusFullScreen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  // Modals
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskModalDefaultDate, setTaskModalDefaultDate] = useState(todayKey);
  const [taskModalDefaultProject, setTaskModalDefaultProject] = useState('');
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);

  // Global Focus Timer State (never resets on view change or fullscreen toggle)
  const [presetId, setPresetId] = useState<TimerPresetId>('pomodoro');
  const [customMinutes, setCustomMinutes] = useState(35);
  const [secondsLeft, setSecondsLeft] = useState(() =>
    getPresetDurationSeconds('pomodoro', 35)
  );
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [focusTaskId, setFocusTaskId] = useState<string | null>(
    () => workspace.tasks.find((t) => !t.completed)?.id || null
  );

  const totalDurationSeconds = useMemo(
    () => getPresetDurationSeconds(presetId, customMinutes),
    [presetId, customMinutes]
  );

  const logCompletedMinutes = useCallback(
    (minutes: number, mode: TimerPresetId, taskId: string | null) => {
      if (minutes <= 0) return;
      const isBreak = mode === 'short_break' || mode === 'long_break';
      const targetTask = taskId
        ? workspace.tasks.find((t) => t.id === taskId) || null
        : null;

      const newSession: FocusSession = {
        id: crypto.randomUUID(),
        taskId: isBreak ? null : taskId,
        projectId: isBreak ? null : targetTask?.projectId || null,
        date: todayKey,
        durationMinutes: minutes,
        mode,
        completedAt: new Date().toISOString(),
      };

      setWorkspace((prev) => ({
        ...prev,
        focusSessions: [newSession, ...prev.focusSessions],
        tasks:
          !isBreak && taskId
            ? prev.tasks.map((t) =>
                t.id === taskId
                  ? { ...t, loggedMinutes: t.loggedMinutes + minutes }
                  : t
              )
            : prev.tasks,
      }));
    },
    [todayKey, workspace.tasks, setWorkspace]
  );

  // Global interval tick
  useEffect(() => {
    if (!isTimerRunning) return;
    const interval = window.setInterval(() => setSecondsLeft(value => Math.max(0, value - 1)), 1000);
    return () => window.clearInterval(interval);
  }, [isTimerRunning]);

  useEffect(() => {
    if (!isTimerRunning || secondsLeft !== 0) return;
    setIsTimerRunning(false);
    setSecondsLeft(totalDurationSeconds);
    logCompletedMinutes(Math.max(1, Math.round(totalDurationSeconds / 60)), presetId, focusTaskId);
  }, [isTimerRunning, secondsLeft, totalDurationSeconds, presetId, focusTaskId, logCompletedMinutes]);

  const dashboardStats = useMemo(
    () => calculateDashboardStats(workspace.tasks, workspace.focusSessions, todayKey, 600),
    [workspace.tasks, workspace.focusSessions, todayKey]
  );

  const pendingTasks = useMemo(
    () => workspace.tasks.filter((t) => !t.completed),
    [workspace.tasks]
  );

  // Task CRUD
  const handleToggleTask = (taskId: string) => {
    setWorkspace((prev) => ({
      ...prev,
      tasks: prev.tasks.map((t) =>
        t.id === taskId ? { ...t, completed: !t.completed } : t
      ),
    }));
  };

  const handleSaveTask = (payload: {
    id?: string;
    title: string;
    projectId: string;
    dueDate: string;
    scheduledTime: string;
    estimatedMinutes: number;
    priority: TaskPriority;
  }) => {
    setWorkspace((prev) => {
      if (payload.id) {
        return {
          ...prev,
          tasks: prev.tasks.map((t) =>
            t.id === payload.id
              ? {
                  ...t,
                  title: payload.title,
                  projectId: payload.projectId,
                  dueDate: payload.dueDate,
                  scheduledTime: payload.scheduledTime,
                  estimatedMinutes: payload.estimatedMinutes,
                  priority: payload.priority,
                }
              : t
          ),
        };
      }
      const created: Task = {
        id: crypto.randomUUID(),
        title: payload.title,
        projectId: payload.projectId,
        dueDate: payload.dueDate,
        scheduledTime: payload.scheduledTime,
        estimatedMinutes: payload.estimatedMinutes,
        loggedMinutes: 0,
        assigneeId: '',
        priority: payload.priority,
        completed: false,
        createdAt: new Date().toISOString(),
      };
      return {
        ...prev,
        tasks: [created, ...prev.tasks],
      };
    });
  };

  const handleDeleteTask = (taskId: string) => {
    setWorkspace((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((t) => t.id !== taskId),
    }));
    if (focusTaskId === taskId) {
      setFocusTaskId(null);
    }
  };

  // Project CRUD
  const handleSaveProject = (projectData: Omit<Project, 'id'>) => {
    const newProject: Project = {
      ...projectData,
      id: crypto.randomUUID(),
    };
    setWorkspace((prev) => ({
      ...prev,
      projects: [...prev.projects, newProject],
    }));
  };

  const handleDeleteProject = (projectId: string) => {
    setWorkspace((prev) => {
      const remainingProjects = prev.projects.filter((p) => p.id !== projectId);
      const fallbackId = remainingProjects[0]?.id;
      return {
        ...prev,
        projects: remainingProjects,
        tasks: prev.tasks.flatMap(task => {
          if (task.projectId !== projectId) return [task];
          return fallbackId ? [{ ...task, projectId: fallbackId }] : [];
        }),
      };
    });
  };

  // Timer handlers
  const handleSelectPreset = (nextPreset: TimerPresetId) => {
    setIsTimerRunning(false);
    setPresetId(nextPreset);
    setSecondsLeft(getPresetDurationSeconds(nextPreset, customMinutes));
  };

  const handleChangeCustomMinutes = (mins: number) => {
    const clamped = Math.max(1, Math.min(180, Number.isNaN(mins) ? 25 : mins));
    setCustomMinutes(clamped);
    if (presetId === 'custom' && !isTimerRunning) {
      setSecondsLeft(clamped * 60);
    }
  };

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setSecondsLeft(totalDurationSeconds);
  };

  const handleCompleteSessionNow = () => {
    const elapsedMins = Math.floor((totalDurationSeconds - secondsLeft) / 60);
    if (elapsedMins >= 1) {
      logCompletedMinutes(elapsedMins, presetId, focusTaskId);
    }
    setIsTimerRunning(false);
    setSecondsLeft(totalDurationSeconds);
  };

  const handleStartFocusOnTask = (taskId: string) => {
    setFocusTaskId(taskId);
    if (presetId === 'short_break' || presetId === 'long_break') {
      setPresetId('pomodoro');
      setSecondsLeft(getPresetDurationSeconds('pomodoro', customMinutes));
    }
    setCurrentView('focus');
  };

  const handleMarkFocusTaskDone = (taskId: string) => {
    const elapsedMins = Math.floor((totalDurationSeconds - secondsLeft) / 60);
    if (elapsedMins >= 1 && presetId !== 'short_break' && presetId !== 'long_break') {
      logCompletedMinutes(elapsedMins, presetId, taskId);
      setIsTimerRunning(false);
      setSecondsLeft(totalDurationSeconds);
    }
    handleToggleTask(taskId);
    const nextPending = pendingTasks.find((t) => t.id !== taskId);
    setFocusTaskId(nextPending?.id || null);
  };

  const handleOpenNewTask = (opts?: { dateKey?: string; projectId?: string }) => {
    if (!workspace.projects.length) {
      setIsProjectModalOpen(true);
      return;
    }
    setEditingTask(null);
    setTaskModalDefaultDate(opts?.dateKey || todayKey);
    setTaskModalDefaultProject(
      opts?.projectId || workspace.projects[0]?.id || ''
    );
    setIsTaskModalOpen(true);
  };

  const isTimerActiveOrPaused = isTimerRunning || secondsLeft < totalDurationSeconds;

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <DashboardView
            tasks={workspace.tasks}
            projects={workspace.projects}
            focusSessions={workspace.focusSessions}
            todayKey={todayKey}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onToggleTask={handleToggleTask}
            onStartFocusTask={handleStartFocusOnTask}
            onOpenNewTask={() => handleOpenNewTask()}
            onEditTask={(task) => {
              setEditingTask(task);
              setIsTaskModalOpen(true);
            }}
            onDeleteTask={handleDeleteTask}
            onSelectProject={(projId) => {
              setSelectedProjectId(projId);
              setCurrentView('projects');
            }}
          />
        );
      case 'projects':
        return (
          <ProjectsView
            projects={workspace.projects}
            tasks={workspace.tasks}
            focusSessions={workspace.focusSessions}
            selectedProjectId={selectedProjectId}
            onSelectProject={setSelectedProjectId}
            onOpenNewProject={() => setIsProjectModalOpen(true)}
            onDeleteProject={handleDeleteProject}
            onOpenNewTaskForProject={(projId) => handleOpenNewTask({ projectId: projId })}
            onToggleTask={handleToggleTask}
            onStartFocusTask={handleStartFocusOnTask}
          />
        );
      case 'calendar':
        return (
          <CalendarView
            tasks={workspace.tasks}
            projects={workspace.projects}
            todayKey={todayKey}
            onToggleTask={handleToggleTask}
            onStartFocusTask={handleStartFocusOnTask}
            onAddTaskOnDate={(dateKey) => handleOpenNewTask({ dateKey })}
          />
        );
      case 'focus':
        return (
          <FocusView
            isFullScreen={isFocusFullScreen}
            onToggleFullScreen={() => setIsFocusFullScreen((v) => !v)}
            presetId={presetId}
            customMinutes={customMinutes}
            secondsLeft={secondsLeft}
            totalDurationSeconds={totalDurationSeconds}
            isRunning={isTimerRunning}
            selectedTaskId={focusTaskId}
            pendingTasks={pendingTasks}
            todayFocusedMinutes={dashboardStats.todayFocusedMinutes}
            onSelectPreset={handleSelectPreset}
            onChangeCustomMinutes={handleChangeCustomMinutes}
            onSelectTask={setFocusTaskId}
            onToggleRun={() => setIsTimerRunning((v) => !v)}
            onResetTimer={handleResetTimer}
            onCompleteSessionNow={handleCompleteSessionNow}
            onMarkActiveTaskDone={handleMarkFocusTaskDone}
          />
        );
      case 'progress':
        return (
          <AnalyticsView
            tasks={workspace.tasks}
            projects={workspace.projects}
            focusSessions={workspace.focusSessions}
            todayKey={todayKey}
          />
        );
      case 'teams':
        return <TeamsView token={token} userId={userId} />;
    }
  };

  return (
    <div className="flex flex-1 min-h-0 w-full bg-[#FBFBFA] text-[#1C1C1A] overflow-hidden">
      {!(currentView === 'focus' && isFocusFullScreen) && (
        <Sidebar
          currentView={currentView}
          isMobileMenuOpen={isMobileMenuOpen}
          onSelectView={(view) => {
            setCurrentView(view);
            if (view !== 'projects') setSelectedProjectId(null);
          }}
          onCloseMobileMenu={() => setIsMobileMenuOpen(false)}
          todayFocusedMinutes={dashboardStats.todayFocusedMinutes}
          weeklyGoalMinutes={dashboardStats.weeklyGoalMinutes}
          weeklyFocusedMinutes={dashboardStats.weeklyFocusedMinutes}
        />
      )}

      <div className="flex-1 flex flex-col min-w-0 h-full relative">
        {!(currentView === 'focus' && isFocusFullScreen) && (
          <Header
            currentView={currentView}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
            onOpenNewTask={() => handleOpenNewTask()}
            isTimerActiveOrPaused={isTimerActiveOrPaused}
            timerSecondsLeft={secondsLeft}
            isTimerRunning={isTimerRunning}
            onJumpToFocus={() => setCurrentView('focus')}
          />
        )}

        <main className="flex-1 overflow-y-auto px-3.5 py-4 md:px-8 md:py-6">
          {renderView()}
        </main>

        {!(currentView === 'focus' && isFocusFullScreen) && (
          <MobileBottomNav
            currentView={currentView}
            onSelectView={(view) => {
              setCurrentView(view);
              if (view !== 'projects') setSelectedProjectId(null);
            }}
          />
        )}
      </div>

      <TaskModal
        isOpen={isTaskModalOpen}
        editingTask={editingTask}
        defaultDateKey={taskModalDefaultDate}
        defaultProjectId={taskModalDefaultProject}
        projects={workspace.projects}
        onClose={() => setIsTaskModalOpen(false)}
        onDelete={handleDeleteTask}
        onSave={handleSaveTask}
      />

      <ProjectModal
        isOpen={isProjectModalOpen}
        defaultDateKey={todayKey}
        onClose={() => setIsProjectModalOpen(false)}
        onSave={handleSaveProject}
      />
    </div>
  );
}

import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Clock,
  Pencil,
  Play,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import type { FocusSession, Project, Task } from '../types/workspace';
import {
  calculateDashboardStats,
  filterAndSortTasks,
  formatMinutesLabel,
  formatTime12h,
} from '../utils/workspaceLogic';

interface DashboardViewProps {
  tasks: Task[];
  projects: Project[];
  focusSessions: FocusSession[];
  todayKey: string;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onToggleTask: (taskId: string) => void;
  onStartFocusTask: (taskId: string) => void;
  onOpenNewTask: () => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onSelectProject: (projectId: string) => void;
}

export function DashboardView({
  tasks,
  projects,
  focusSessions,
  todayKey,
  searchQuery,
  onSearchChange,
  onToggleTask,
  onStartFocusTask,
  onOpenNewTask,
  onEditTask,
  onDeleteTask,
  onSelectProject,
}: DashboardViewProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed'>('all');
  const [scope, setScope] = useState<'today' | 'all'>('today');

  const stats = useMemo(
    () => calculateDashboardStats(tasks, focusSessions, todayKey, 600),
    [tasks, focusSessions, todayKey]
  );

  const projectById = useMemo(() => {
    const map = new Map<string, Project>();
    projects.forEach((p) => map.set(p.id, p));
    return map;
  }, [projects]);

  const visibleTasks = useMemo(
    () =>
      filterAndSortTasks(tasks, {
        search: searchQuery,
        status: statusFilter,
        dateKey: scope === 'today' ? todayKey : undefined,
      }),
    [tasks, searchQuery, statusFilter, scope, todayKey]
  );

  const upcomingDeadlines = useMemo(
    () => projects.slice().sort((a, b) => a.dueDate.localeCompare(b.dueDate)),
    [projects]
  );

  const timeProgressPercent =
    stats.todayPlannedMinutes > 0
      ? Math.min(100, Math.round((stats.todayFocusedMinutes / stats.todayPlannedMinutes) * 100))
      : 0;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 md:pb-6">
      {/* KPI Summary Strip */}
      <section aria-label="Daily workspace metrics" className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        <div className="bg-white border border-[#E6E6E2] rounded-xl p-4">
          <p className="text-xs font-medium text-[#63635E]">Tasks Done Today</p>
          <p className="mt-2 text-2xl md:text-[28px] font-semibold text-[#1C1C1A] font-mono tabular-nums">
            {stats.todayCompletedTasks}
            <span className="text-sm font-normal text-[#7A7A74]">/{stats.todayTotalTasks}</span>
          </p>
        </div>

        <div className="bg-white border border-[#E6E6E2] rounded-xl p-4">
          <p className="text-xs font-medium text-[#63635E]">Focused Today</p>
          <p className="mt-2 text-2xl md:text-[28px] font-semibold text-[#1C1C1A] font-mono tabular-nums">
            {formatMinutesLabel(stats.todayFocusedMinutes)}
          </p>
        </div>

        <div className="bg-white border border-[#E6E6E2] rounded-xl p-4">
          <p className="text-xs font-medium text-[#63635E]">Planned Today</p>
          <p className="mt-2 text-2xl md:text-[28px] font-semibold text-[#1C1C1A] font-mono tabular-nums">
            {formatMinutesLabel(stats.todayPlannedMinutes)}
          </p>
        </div>

        <div className="bg-white border border-[#E6E6E2] rounded-xl p-4">
          <p className="text-xs font-medium text-[#63635E]">Remaining Work</p>
          <p className="mt-2 text-2xl md:text-[28px] font-semibold text-[#1C1C1A] font-mono tabular-nums">
            {formatMinutesLabel(stats.todayRemainingMinutes)}
          </p>
        </div>
      </section>

      {/* Time Control Budget Bar */}
      <section className="bg-white border border-[#E6E6E2] rounded-xl p-4 md:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div>
            <h2 className="text-sm font-semibold text-[#1C1C1A]">Daily Time Budget</h2>
            <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
              {formatMinutesLabel(stats.todayFocusedMinutes)} logged ·{' '}
              {formatMinutesLabel(stats.todayPlannedMinutes)} planned ·{' '}
              {formatMinutesLabel(stats.todayRemainingMinutes)} left
            </p>
          </div>
          <span className="text-xs font-mono tabular-nums font-semibold text-[#4F46E5]">
            {timeProgressPercent}% of plan
          </span>
        </div>
        <div className="w-full h-2 bg-[#EFEFEA] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#4F46E5] rounded-full transition-all duration-300"
            style={{ width: `${timeProgressPercent}%` }}
          />
        </div>
      </section>

      {/* Main Split: Task List + Deadlines */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <section className="lg:col-span-2 bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
          <div className="p-4 border-b border-[#E6E6E2] space-y-3">
            <div className="flex items-center justify-between gap-2 overflow-x-auto">
              <div className="flex items-center gap-0.5 p-1 bg-[#F5F5F2] rounded-lg shrink-0">
                <button
                  type="button"
                  onClick={() => setScope('today')}
                  className={`h-8 px-2.5 sm:px-3 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                    scope === 'today'
                      ? 'bg-white text-[#1C1C1A] shadow-xs'
                      : 'text-[#63635E] hover:text-[#1C1C1A]'
                  }`}
                >
                  Today
                </button>
                <button
                  type="button"
                  onClick={() => setScope('all')}
                  className={`h-8 px-2.5 sm:px-3 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                    scope === 'all'
                      ? 'bg-white text-[#1C1C1A] shadow-xs'
                      : 'text-[#63635E] hover:text-[#1C1C1A]'
                  }`}
                >
                  All Tasks
                </button>
              </div>

              <div className="flex items-center gap-0.5 p-1 bg-[#F5F5F2] rounded-lg shrink-0">
                {(['all', 'active', 'completed'] as const).map((tab) => (
                  <button
                    key={tab}
                    type="button"
                    onClick={() => setStatusFilter(tab)}
                    className={`h-8 px-2 sm:px-2.5 rounded-md text-xs font-medium capitalize transition-colors whitespace-nowrap ${
                      statusFilter === tab
                        ? 'bg-white text-[#1C1C1A] shadow-xs'
                        : 'text-[#63635E] hover:text-[#1C1C1A]'
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile Search Input */}
            <div className="lg:hidden relative">
              <Search className="w-4 h-4 text-[#7A7A74] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search tasks..."
                aria-label="Search tasks"
                className="w-full h-10 pl-9 pr-9 text-sm bg-[#F5F5F2] border border-[#E6E6E2] rounded-lg text-[#1C1C1A] placeholder:text-[#7A7A74] focus:outline-none focus:border-[#4F46E5] focus:bg-white"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  aria-label="Clear search"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-[#63635E]"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {visibleTasks.length === 0 ? (
            <div className="px-6 py-12 text-center space-y-3">
              <p className="text-sm font-medium text-[#1C1C1A]">
                {searchQuery
                  ? `No tasks match "${searchQuery}".`
                  : scope === 'today'
                    ? 'No tasks scheduled for today in this filter.'
                    : 'No tasks found.'}
              </p>
              <p className="text-xs text-[#63635E]">
                Add a task with a time estimate to plan your focus blocks.
              </p>
              <button
                type="button"
                onClick={onOpenNewTask}
                className="inline-flex items-center gap-1.5 h-10 px-4 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-medium transition-colors"
              >
                <Plus className="w-4 h-4" /> Add Task
              </button>
            </div>
          ) : (
            <ul className="divide-y divide-[#EFEFEA]" data-testid="dashboard-task-list">
              {visibleTasks.map((task) => {
                const project = projectById.get(task.projectId);
                return (
                  <li
                    key={task.id}
                    className="px-3 md:px-4 py-3 hover:bg-[#FAF9F6] transition-colors flex items-center gap-2 md:gap-3"
                  >
                    <button
                      type="button"
                      onClick={() => onToggleTask(task.id)}
                      aria-label={
                        task.completed
                          ? `Mark "${task.title}" as incomplete`
                          : `Mark "${task.title}" as complete`
                      }
                      className="min-w-[44px] min-h-[44px] -ml-1.5 flex items-center justify-center shrink-0"
                    >
                      <span
                        className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                          task.completed
                            ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                            : 'border-[#C9C9C2] bg-white hover:border-[#4F46E5]'
                        }`}
                      >
                        {task.completed && <Check className="w-3 h-3" />}
                      </span>
                    </button>

                    <div className="flex-1 min-w-0">
                      <p
                        className={`text-sm md:text-[15px] font-medium line-clamp-2 sm:truncate ${
                          task.completed ? 'line-through text-[#7A7A74]' : 'text-[#1C1C1A]'
                        }`}
                      >
                        {task.title}
                      </p>
                      <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-[#63635E]">
                        <span>{project?.name || 'Workspace'}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">
                          {formatTime12h(task.scheduledTime)}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                          <Clock className="w-3 h-3" />
                          {task.estimatedMinutes}m
                          {task.loggedMinutes > 0 ? ` (${task.loggedMinutes}m done)` : ''}
                        </span>
                        {task.priority === 'high' && !task.completed && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-[#DC2626] font-medium">High</span>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-0.5 sm:gap-1 shrink-0">
                      {!task.completed && (
                        <button
                          type="button"
                          onClick={() => onStartFocusTask(task.id)}
                          aria-label={`Start focus session for "${task.title}"`}
                          title="Focus on this task"
                          className="min-w-[40px] min-h-[40px] sm:px-2.5 rounded-lg text-xs font-medium text-[#4F46E5] hover:bg-[#EEF2FF] flex items-center justify-center gap-1 transition-colors"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span className="hidden sm:inline">Focus</span>
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onEditTask(task)}
                        aria-label={`Edit "${task.title}"`}
                        title="Edit task"
                        className="min-w-[40px] min-h-[40px] rounded-lg text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F0F0EC] flex items-center justify-center transition-colors"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteTask(task.id)}
                        aria-label={`Delete "${task.title}"`}
                        title="Delete task"
                        className="hidden sm:flex min-w-[40px] min-h-[40px] rounded-lg text-[#63635E] hover:text-[#DC2626] hover:bg-[#FEF2F2] items-center justify-center transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}

          <div className="px-4 py-3 border-t border-[#E6E6E2] bg-[#FAF9F6]">
            <button
              type="button"
              onClick={onOpenNewTask}
              className="min-h-[40px] flex items-center gap-2 text-sm font-medium text-[#4F46E5] hover:text-[#4338CA] transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Task</span>
            </button>
          </div>
        </section>

        {/* Project Deadlines Sidebar */}
        <section className="bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
          <div className="px-4 py-3.5 border-b border-[#E6E6E2]">
            <h2 className="text-sm font-semibold text-[#1C1C1A]">Project Deadlines</h2>
          </div>
          <ul className="divide-y divide-[#EFEFEA]">
            {upcomingDeadlines.map((project) => (
              <li key={project.id}>
                <button
                  type="button"
                  onClick={() => onSelectProject(project.id)}
                  className="w-full px-4 py-3.5 text-left hover:bg-[#FAF9F6] transition-colors flex items-center justify-between gap-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#1C1C1A] truncate">{project.name}</p>
                    <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
                      Due {project.dueDate}
                    </p>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-medium whitespace-nowrap shrink-0 ${
                      project.status === 'At Risk' ? 'text-[#B45309]' : 'text-[#15803D]'
                    }`}
                  >
                    {project.status === 'At Risk' ? (
                      <AlertTriangle className="w-3.5 h-3.5" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    )}
                    {project.status}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}

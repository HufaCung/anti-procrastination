import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  FolderKanban,
  Play,
  Plus,
  Trash2,
} from 'lucide-react';
import type { FocusSession, Project, Task } from '../types/workspace';
import {
  calculateProjectProgress,
  filterAndSortTasks,
  formatMinutesLabel,
  formatTime12h,
} from '../utils/workspaceLogic';

interface ProjectsViewProps {
  projects: Project[];
  tasks: Task[];
  focusSessions: FocusSession[];
  selectedProjectId: string | null;
  onSelectProject: (projectId: string | null) => void;
  onOpenNewProject: () => void;
  onDeleteProject: (projectId: string) => void;
  onOpenNewTaskForProject: (projectId: string) => void;
  onToggleTask: (taskId: string) => void;
  onStartFocusTask: (taskId: string) => void;
}

export function ProjectsView({
  projects,
  tasks,
  focusSessions,
  selectedProjectId,
  onSelectProject,
  onOpenNewProject,
  onDeleteProject,
  onOpenNewTaskForProject,
  onToggleTask,
  onStartFocusTask,
}: ProjectsViewProps) {
  const [statusFilter, setStatusFilter] = useState<'all' | 'On Track' | 'At Risk'>('all');

  const selectedProject = useMemo(
    () => projects.find((p) => p.id === selectedProjectId) || null,
    [projects, selectedProjectId]
  );

  const visibleProjects = useMemo(() => {
    if (statusFilter === 'all') return projects;
    return projects.filter((p) => p.status === statusFilter);
  }, [projects, statusFilter]);

  if (selectedProject) {
    const progress = calculateProjectProgress(selectedProject.id, tasks, focusSessions);
    const projectTasks = filterAndSortTasks(tasks, { projectId: selectedProject.id });

    return (
      <div className="max-w-5xl mx-auto space-y-6 pb-20 md:pb-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => onSelectProject(null)}
            className="h-10 px-3 -ml-2 rounded-lg text-sm font-medium text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#EFEFEA] inline-flex items-center gap-2 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>All Projects</span>
          </button>

          <div className="flex items-center gap-2">
            {projects.length > 1 && (
              <button
                type="button"
                onClick={() => {
                  onDeleteProject(selectedProject.id);
                  onSelectProject(null);
                }}
                className="h-10 px-3 rounded-lg border border-[#E6E6E2] text-sm font-medium text-[#DC2626] hover:bg-[#FEF2F2] inline-flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete Project</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => onOpenNewTaskForProject(selectedProject.id)}
              className="h-10 px-4 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-medium inline-flex items-center gap-1.5 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Task to Project</span>
            </button>
          </div>
        </div>

        <div className="bg-white border border-[#E6E6E2] rounded-xl p-5 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold text-[#1C1C1A]">{selectedProject.name}</h2>
              <p className="text-sm text-[#63635E] mt-1">{selectedProject.description}</p>
            </div>
            <div className="text-right font-mono tabular-nums text-xs text-[#63635E] space-y-1">
              <p>
                Due <span className="text-[#1C1C1A] font-medium">{selectedProject.dueDate}</span>
              </p>
              <p>
                {formatMinutesLabel(progress.loggedMinutes)} logged ·{' '}
                {formatMinutesLabel(progress.estimatedMinutes)} estimated
              </p>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#63635E]">
                {progress.completedTasks} of {progress.totalTasks} tasks complete
              </span>
              <span className="font-mono tabular-nums font-semibold text-[#1C1C1A]">
                {progress.completionPercent}%
              </span>
            </div>
            <div className="w-full h-2 bg-[#EFEFEA] rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-300"
                style={{
                  width: `${progress.completionPercent}%`,
                  backgroundColor: selectedProject.accentHex,
                }}
              />
            </div>
          </div>
        </div>

        <div className="bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
          {projectTasks.length === 0 ? (
            <div className="p-10 text-center space-y-3">
              <p className="text-sm font-medium text-[#1C1C1A]">No tasks in this project yet.</p>
              <button
                type="button"
                onClick={() => onOpenNewTaskForProject(selectedProject.id)}
                className="h-10 px-4 rounded-lg bg-[#4F46E5] text-white text-sm font-medium inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" /> Add First Task
              </button>
            </div>
          ) : (
            <ul className="divide-y divide-[#EFEFEA]">
              {projectTasks.map((task) => (
                <li key={task.id} className="px-4 py-3 flex items-center gap-3 hover:bg-[#FAF9F6]">
                  <button
                    type="button"
                    onClick={() => onToggleTask(task.id)}
                    aria-label={
                      task.completed
                        ? `Mark "${task.title}" incomplete`
                        : `Mark "${task.title}" complete`
                    }
                    className="min-w-[44px] min-h-[44px] -ml-1.5 flex items-center justify-center shrink-0"
                  >
                    <span
                      className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                        task.completed
                          ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                          : 'border-[#C9C9C2] bg-white'
                      }`}
                    >
                      {task.completed && <Check className="w-3 h-3" />}
                    </span>
                  </button>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-sm font-medium truncate ${
                        task.completed ? 'line-through text-[#7A7A74]' : 'text-[#1C1C1A]'
                      }`}
                    >
                      {task.title}
                    </p>
                    <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
                      {task.dueDate} · {formatTime12h(task.scheduledTime)} · {task.estimatedMinutes}m
                    </p>
                  </div>
                  {!task.completed && (
                    <button
                      type="button"
                      onClick={() => onStartFocusTask(task.id)}
                      aria-label={`Focus on "${task.title}"`}
                      className="h-9 px-3 rounded-lg text-xs font-medium text-[#4F46E5] hover:bg-[#EEF2FF] inline-flex items-center gap-1 shrink-0"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Focus</span>
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 md:pb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 p-1 bg-[#EFEFEA] rounded-lg">
          {(['all', 'On Track', 'At Risk'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setStatusFilter(tab)}
              className={`h-8 px-3 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === tab
                  ? 'bg-white text-[#1C1C1A] shadow-xs'
                  : 'text-[#63635E] hover:text-[#1C1C1A]'
              }`}
            >
              {tab === 'all' ? 'All Projects' : tab}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={onOpenNewProject}
          className="h-10 px-4 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap"
        >
          <Plus className="w-4 h-4" />
          <span>New Project</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {visibleProjects.map((project) => {
          const prog = calculateProjectProgress(project.id, tasks, focusSessions);
          return (
            <button
              key={project.id}
              type="button"
              onClick={() => onSelectProject(project.id)}
              className="text-left bg-white border border-[#E6E6E2] hover:border-[#C9C9C2] rounded-xl p-5 transition-colors flex flex-col justify-between gap-4"
            >
              <div className="space-y-3 w-full">
                <div className="flex items-center justify-between gap-2">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${project.accentHex}18`, color: project.accentHex }}
                  >
                    <FolderKanban className="w-4 h-4" />
                  </div>
                  <span
                    className={`inline-flex items-center gap-1 text-xs font-medium ${
                      project.status === 'At Risk' ? 'text-[#B45309]' : 'text-[#15803D]'
                    }`}
                  >
                    {project.status === 'At Risk' ? (
                      <AlertTriangle className="w-3.5 h-3.5" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    )}
                    {project.status}
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-semibold text-[#1C1C1A]">{project.name}</h3>
                  <p className="text-xs text-[#63635E] mt-1 line-clamp-2">{project.description}</p>
                </div>
              </div>

              <div className="w-full space-y-2 pt-2 border-t border-[#EFEFEA]">
                <div className="flex items-center justify-between text-xs text-[#63635E] font-mono tabular-nums">
                  <span>
                    {prog.completedTasks}/{prog.totalTasks} tasks
                  </span>
                  <span>
                    {formatMinutesLabel(prog.loggedMinutes)} / {formatMinutesLabel(prog.estimatedMinutes)}
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#EFEFEA] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{
                      width: `${prog.completionPercent}%`,
                      backgroundColor: project.accentHex,
                    }}
                  />
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

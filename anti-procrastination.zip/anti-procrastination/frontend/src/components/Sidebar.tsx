import React from 'react';
import {
  LayoutDashboard,
  FolderKanban,
  CalendarDays,
  Timer,
  LineChart,
  Users,
  CheckCircle2,
  X,
} from 'lucide-react';
import type { ViewId } from '../types/workspace';
import { formatMinutesLabel } from '../utils/workspaceLogic';

export interface NavItem {
  id: ViewId;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const NAVIGATION_ITEMS: NavItem[] = [
  { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
  { id: 'projects', name: 'Projects', icon: FolderKanban },
  { id: 'calendar', name: 'Calendar', icon: CalendarDays },
  { id: 'focus', name: 'Focus Mode', icon: Timer },
  { id: 'progress', name: 'Analytics', icon: LineChart },
  { id: 'teams', name: 'Teams', icon: Users },
];

interface SidebarProps {
  currentView: ViewId;
  isMobileMenuOpen: boolean;
  onSelectView: (view: ViewId) => void;
  onCloseMobileMenu: () => void;
  todayFocusedMinutes: number;
  weeklyGoalMinutes: number;
  weeklyFocusedMinutes: number;
}

export function Sidebar({
  currentView,
  isMobileMenuOpen,
  onSelectView,
  onCloseMobileMenu,
  todayFocusedMinutes,
  weeklyGoalMinutes,
  weeklyFocusedMinutes,
}: SidebarProps) {
  const weeklyPercent =
    weeklyGoalMinutes > 0
      ? Math.min(100, Math.round((weeklyFocusedMinutes / weeklyGoalMinutes) * 100))
      : 0;

  return (
    <>
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-[#1C1C1A]/40 z-40 md:hidden backdrop-blur-[2px] transition-opacity duration-200"
          onClick={onCloseMobileMenu}
          aria-hidden="true"
        />
      )}

      <aside
        aria-label="Primary Workspace Navigation"
        className={`fixed inset-y-0 left-0 z-50 w-[260px] bg-[#F5F5F2] border-r border-[#E6E6E2] transform transition-transform duration-200 ease-[cubic-bezier(0.16,1,0.3,1)] flex flex-col
          ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'} md:relative md:translate-x-0 md:shadow-none`}
      >
        <div className="flex items-center justify-between h-[56px] md:h-[64px] px-5 border-b border-[#E6E6E2] shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#4F46E5] flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-white" />
            </div>
            <span className="text-[17px] font-bold tracking-tight text-[#1C1C1A] whitespace-nowrap">
              TinyDo
            </span>
          </div>

          <button
            type="button"
            onClick={onCloseMobileMenu}
            aria-label="Close navigation menu"
            className="md:hidden min-w-[44px] min-h-[44px] -mr-2 flex items-center justify-center rounded-lg text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#EAEAE5] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {NAVIGATION_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobileMenu();
                }}
                aria-current={isActive ? 'page' : undefined}
                className={`w-full min-h-[44px] flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap
                  ${
                    isActive
                      ? 'bg-[#EAEAE4] text-[#1C1C1A]'
                      : 'text-[#63635E] hover:bg-[#EFEFEA] hover:text-[#1C1C1A]'
                  }`}
              >
                <Icon
                  className={`w-[18px] h-[18px] shrink-0 ${
                    isActive ? 'text-[#4F46E5]' : 'text-[#7A7A74]'
                  }`}
                />
                <span>{item.name}</span>
              </button>
            );
          })}
        </nav>

        <div className="px-4 py-3 border-t border-[#E6E6E2] space-y-3 shrink-0">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-[#63635E]">Weekly Focus Goal</span>
              <span className="font-mono tabular-nums font-medium text-[#1C1C1A]">
                {weeklyPercent}%
              </span>
            </div>
            <div className="w-full h-1.5 bg-[#E6E6E2] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#4F46E5] rounded-full transition-all duration-300"
                style={{ width: `${weeklyPercent}%` }}
              />
            </div>
            <p className="text-[11px] text-[#63635E] font-mono tabular-nums">
              {formatMinutesLabel(todayFocusedMinutes)} today �{' '}
              {formatMinutesLabel(weeklyFocusedMinutes)} / {formatMinutesLabel(weeklyGoalMinutes)}
            </p>
          </div>

        </div>
      </aside>
    </>
  );
}

import { useState } from 'react';
import type { SafeUser } from '../../../backend/src/types';
import { request } from '../data/api';
import { SyncedWorkspace } from './SyncedWorkspace';

export function Account() {
  const [account, setAccount] = useState<{ token: string; user: SafeUser }>();
  const [signup, setSignup] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  if (account) return <SyncedWorkspace key={account.user.id} {...account} signOut={() => setAccount(undefined)} />;

  return <main className="mx-auto max-w-md px-4 py-12">
    <h1 className="mb-4 text-2xl font-bold">TinyDo</h1>
    <form className="grid gap-3" onSubmit={async event => {
      event.preventDefault();
      const fields = new FormData(event.currentTarget);
      setBusy(true);
      setError('');
      try {
        setAccount(await request('/auth/' + (signup ? 'signup' : 'login'), '', 'POST', Object.fromEntries(fields)));
      } catch (error) {
        setError(error instanceof Error ? error.message : 'Could not sign in');
      } finally {
        setBusy(false);
      }
    }}>
      <label>Username<input className="block w-full rounded border p-2" name="username" autoComplete="username" required /></label>
      <label>Password<input className="block w-full rounded border p-2" name="password" type="password" autoComplete={signup ? 'new-password' : 'current-password'} required minLength={signup ? 8 : undefined} /></label>
      {error && <p role="alert">{error}</p>}
      <button className="rounded bg-[#4f7d64] p-2 text-white" disabled={busy}>{signup ? 'Create account' : 'Sign in'}</button>
      <button type="button" onClick={() => { setSignup(!signup); setError(''); }} disabled={busy}>{signup ? 'Back to sign in' : 'Create an account'}</button>
    </form>
  </main>;
}

import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import type { Project } from '../types/workspace';

interface ProjectModalProps {
  isOpen: boolean;
  defaultDateKey: string;
  onClose: () => void;
  onSave: (project: Omit<Project, 'id'>) => void;
}

const ACCENT_SWATCHES = [
  { label: 'Indigo', hex: '#4F46E5' },
  { label: 'Sky', hex: '#0EA5E9' },
  { label: 'Emerald', hex: '#16A34A' },
  { label: 'Amber', hex: '#D97706' },
  { label: 'Rose', hex: '#E11D48' },
];

export function ProjectModal({ isOpen, defaultDateKey, onClose, onSave }: ProjectModalProps) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState(defaultDateKey);
  const [weeklyTargetMinutes, setWeeklyTargetMinutes] = useState(240);
  const [accentHex, setAccentHex] = useState('#4F46E5');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setName('');
    setDescription('');
    setDueDate(defaultDateKey);
    setWeeklyTargetMinutes(240);
    setAccentHex('#4F46E5');
    setError('');
  }, [isOpen, defaultDateKey]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Please enter a project name.');
      return;
    }
    onSave({
      name: trimmed,
      description: description.trim() || 'Active workspace initiative',
      accentHex,
      dueDate,
      status: 'On Track',
      weeklyTargetMinutes: Math.max(30, Number(weeklyTargetMinutes) || 240),
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-[#1C1C1A]/40 backdrop-blur-[2px] p-0 md:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="project-modal-title"
    >
      <div className="w-full md:max-w-md bg-white border border-[#E6E6E2] rounded-t-2xl md:rounded-xl shadow-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E6E6E2]">
          <h2 id="project-modal-title" className="text-base font-semibold text-[#1C1C1A]">
            New Project
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close project dialog"
            className="min-w-[40px] min-h-[40px] -mr-2 flex items-center justify-center rounded-lg text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F4F4F1]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <div>
            <label htmlFor="project-name-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
              Project Name
            </label>
            <input
              id="project-name-input"
              type="text"
              autoFocus
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g., Q1 Mobile Sprint"
              className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] focus:outline-none focus:border-[#4F46E5]"
            />
            {error && <p className="mt-1.5 text-xs text-[#DC2626]">{error}</p>}
          </div>

          <div>
            <label htmlFor="project-desc-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
              Summary
            </label>
            <input
              id="project-desc-input"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Brief scope or milestone goal"
              className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] focus:outline-none focus:border-[#4F46E5]"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="project-due-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
                Target Date
              </label>
              <input
                id="project-due-input"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] font-mono tabular-nums focus:outline-none focus:border-[#4F46E5]"
              />
            </div>

            <div>
              <label htmlFor="project-target-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
                Weekly Target (min)
              </label>
              <input
                id="project-target-input"
                type="number"
                min={30}
                step={30}
                value={weeklyTargetMinutes}
                onChange={(e) => setWeeklyTargetMinutes(Number(e.target.value))}
                className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] font-mono tabular-nums focus:outline-none focus:border-[#4F46E5]"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-[#63635E] mb-2">Accent Color</span>
            <div className="flex items-center gap-2.5">
              {ACCENT_SWATCHES.map((swatch) => (
                <button
                  key={swatch.hex}
                  type="button"
                  onClick={() => setAccentHex(swatch.hex)}
                  aria-label={`Select ${swatch.label} accent`}
                  className={`w-8 h-8 rounded-full transition-transform ${
                    accentHex === swatch.hex
                      ? 'ring-2 ring-offset-2 ring-[#1C1C1A] scale-110'
                      : 'hover:scale-105'
                  }`}
                  style={{ backgroundColor: swatch.hex }}
                />
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2.5 border-t border-[#E6E6E2]">
            <button
              type="button"
              onClick={onClose}
              className="h-10 px-4 rounded-lg border border-[#E6E6E2] text-sm font-medium text-[#63635E] hover:text-[#1C1C1A]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="h-10 px-5 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-medium"
            >
              Create Project
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

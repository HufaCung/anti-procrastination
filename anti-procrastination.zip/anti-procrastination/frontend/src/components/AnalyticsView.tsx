import React, { useMemo, useState } from 'react';
import type { FocusSession, Project, Task } from '../types/workspace';
import {
  buildProjectTimeBreakdown,
  buildWeeklyFocusBars,
  calculateDashboardStats,
  formatMinutesLabel,
} from '../utils/workspaceLogic';

interface AnalyticsViewProps {
  tasks: Task[];
  projects: Project[];
  focusSessions: FocusSession[];
  todayKey: string;
}

export function AnalyticsView({
  tasks,
  projects,
  focusSessions,
  todayKey,
}: AnalyticsViewProps) {
  const stats = useMemo(
    () => calculateDashboardStats(tasks, focusSessions, todayKey, 600),
    [tasks, focusSessions, todayKey]
  );

  const weeklyBars = useMemo(
    () => buildWeeklyFocusBars(focusSessions, todayKey),
    [focusSessions, todayKey]
  );

  const [selectedDayKey, setSelectedDayKey] = useState<string>(todayKey);

  const selectedDayBar =
    weeklyBars.find((b) => b.dateKey === selectedDayKey) || weeklyBars[weeklyBars.length - 1];

  const projectBreakdown = useMemo(
    () => buildProjectTimeBreakdown(projects, tasks, focusSessions),
    [projects, tasks, focusSessions]
  );

  const taskById = useMemo(() => {
    const map = new Map<string, Task>();
    tasks.forEach((t) => map.set(t.id, t));
    return map;
  }, [tasks]);

  const projectById = useMemo(() => {
    const map = new Map<string, Project>();
    projects.forEach((p) => map.set(p.id, p));
    return map;
  }, [projects]);

  const recentSessions = useMemo(
    () =>
      focusSessions
        .filter((s) => s.mode !== 'short_break' && s.mode !== 'long_break')
        .slice()
        .sort((a, b) => b.completedAt.localeCompare(a.completedAt))
        .slice(0, 6),
    [focusSessions]
  );

  const ringCircumference = 2 * Math.PI * 42;
  const ringOffset =
    ringCircumference - (ringCircumference * stats.overallCompletionRate) / 100;

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-20 md:pb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Weekly Focus Bar Chart */}
        <section className="bg-white border border-[#E6E6E2] rounded-xl p-5">
          <div className="flex items-start justify-between gap-3 mb-6">
            <div>
              <h2 className="text-sm font-semibold text-[#1C1C1A]">Weekly Focus Time</h2>
              <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
                {formatMinutesLabel(stats.weeklyFocusedMinutes)} total over last 7 days
              </p>
            </div>
            {selectedDayBar && (
              <div className="text-right font-mono tabular-nums">
                <p className="text-sm font-semibold text-[#4F46E5]">
                  {formatMinutesLabel(selectedDayBar.minutes)}
                </p>
                <p className="text-[11px] text-[#63635E]">{selectedDayBar.dateKey}</p>
              </div>
            )}
          </div>

          <div className="flex items-end justify-between gap-2 h-44">
            {weeklyBars.map((bar) => {
              const isSelected = bar.dateKey === selectedDayBar?.dateKey;
              return (
                <button
                  key={bar.dateKey}
                  type="button"
                  onClick={() => setSelectedDayKey(bar.dateKey)}
                  aria-label={`${bar.dayLabel} ${bar.dateKey}: ${bar.minutes} minutes focused`}
                  className="flex-1 h-full flex flex-col justify-end items-center gap-2 group"
                >
                  <div className="w-full flex-1 bg-[#F5F5F2] rounded-md relative flex items-end overflow-hidden">
                    <div
                      className={`w-full rounded-md transition-all duration-300 ${
                        isSelected
                          ? 'bg-[#4F46E5]'
                          : 'bg-[#A5B4FC] group-hover:bg-[#6366F1]'
                      }`}
                      style={{ height: `${bar.heightPercent}%` }}
                    />
                  </div>
                  <span
                    className={`text-xs font-medium ${
                      isSelected ? 'text-[#4F46E5]' : 'text-[#63635E]'
                    }`}
                  >
                    {bar.dayLabel}
                  </span>
                </button>
              );
            })}
          </div>
        </section>

        {/* Task Completion Ring */}
        <section className="bg-white border border-[#E6E6E2] rounded-xl p-5 flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-[#1C1C1A]">Overall Completion Rate</h2>
            <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
              {tasks.filter((t) => t.completed).length} of {tasks.length} workspace tasks completed
            </p>
          </div>

          <div className="flex items-center justify-center py-6">
            <div className="relative w-36 h-36">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100" aria-hidden="true">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#EFEFEA" strokeWidth="10" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="#4F46E5"
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  strokeDashoffset={ringOffset}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-bold text-[#1C1C1A] font-mono tabular-nums">
                  {stats.overallCompletionRate}%
                </span>
                <span className="text-[11px] text-[#63635E]">Completed</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Project Time Breakdown */}
        <section className="bg-white border border-[#E6E6E2] rounded-xl p-5 space-y-4">
          <h2 className="text-sm font-semibold text-[#1C1C1A]">Time by Project</h2>
          <div className="space-y-4">
            {projectBreakdown.map((item) => (
              <div key={item.project.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-[#1C1C1A]">{item.project.name}</span>
                  <span className="font-mono tabular-nums text-[#63635E]">
                    {formatMinutesLabel(item.focusedMinutes)} ({item.sharePercent}%)
                  </span>
                </div>
                <div className="w-full h-2 bg-[#EFEFEA] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${item.sharePercent}%`,
                      backgroundColor: item.project.accentHex,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Recent Focus Sessions */}
        <section className="bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-[#E6E6E2]">
            <h2 className="text-sm font-semibold text-[#1C1C1A]">Recent Focus Sessions</h2>
          </div>
          {recentSessions.length === 0 ? (
            <p className="p-6 text-sm text-[#63635E]">No focus sessions logged yet.</p>
          ) : (
            <ul className="divide-y divide-[#EFEFEA]">
              {recentSessions.map((session) => {
                const task = session.taskId ? taskById.get(session.taskId) : null;
                const proj = session.projectId ? projectById.get(session.projectId) : null;
                return (
                  <li key={session.id} className="px-5 py-3 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#1C1C1A] truncate">
                        {task?.title || 'Deep Work Session'}
                      </p>
                      <p className="text-xs text-[#63635E] mt-0.5 font-mono tabular-nums">
                        {session.date} · {proj?.name || 'General'}
                      </p>
                    </div>
                    <span className="text-xs font-mono tabular-nums font-semibold text-[#4F46E5] shrink-0">
                      +{formatMinutesLabel(session.durationMinutes)}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}

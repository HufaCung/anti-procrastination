import { useCallback, useEffect, useRef, useState } from 'react';
import type { SafeUser } from '../../../backend/src/types';
import App from '../App';
import { ApiError, request } from '../data/api';
import { fromServer, toServer, type Snapshot } from '../data/workspaceSync';
import type { Workspace } from '../types/workspace';

const legacyKey = 'tinydo_workspace_v1';
type Draft = { workspace: Workspace; revision: number; imported?: boolean };

function readStored<T>(key: string, tabOnly = false): T | undefined {
  try { return JSON.parse((tabOnly ? sessionStorage : localStorage).getItem(key) || 'null') ?? undefined; }
  catch { return undefined; }
}

function readLegacy(): Workspace | undefined {
  const old = readStored<Workspace>(legacyKey);
  if (old && Array.isArray(old.projects) && Array.isArray(old.tasks) && Array.isArray(old.focusSessions)) return old;
}

function rekey(workspace: Workspace): Workspace {
  const projects = new Map(workspace.projects.map(project => [project.id, crypto.randomUUID()]));
  const tasks = new Map(workspace.tasks.map(task => [task.id, crypto.randomUUID()]));
  return {
    projects: workspace.projects.map(project => ({ ...project, id: projects.get(project.id)! })),
    tasks: workspace.tasks.flatMap(task => {
      const projectId = projects.get(task.projectId);
      return projectId ? [{ ...task, id: tasks.get(task.id)!, projectId, assigneeId: '' }] : [];
    }),
    focusSessions: workspace.focusSessions.map(session => ({
      ...session, id: crypto.randomUUID(),
      taskId: session.taskId ? tasks.get(session.taskId) ?? null : null,
      projectId: session.projectId ? projects.get(session.projectId) ?? null : null,
    })),
  };
}

function describeChanges(local: Workspace, remote: Workspace) {
  return (['projects', 'tasks', 'focusSessions'] as const).map(key => {
    const current = new Map(local[key].map(item => [item.id, JSON.stringify(item)] as const));
    const previous = new Map(remote[key].map(item => [item.id, JSON.stringify(item)] as const));
    let added = 0;
    let updated = 0;
    let removed = 0;
    for (const [id, value] of current) {
      if (!previous.has(id)) added++;
      else if (previous.get(id) !== value) updated++;
    }
    for (const id of previous.keys()) if (!current.has(id)) removed++;
    return { key, added, updated, removed };
  });
}

export function SyncedWorkspace({ user, token, signOut }: { user: SafeUser; token: string; signOut: () => void }) {
  const key = 'tinydo:draft:' + user.id;
  const [draft, setDraft] = useState<Draft | undefined>(() => readStored<Draft>(key, true));
  const draftRef = useRef(draft);
  const workspaceRef = useRef<Workspace | undefined>(undefined);
  const [snapshot, setSnapshot] = useState<Snapshot>();
  const [workspace, setWorkspace] = useState<Workspace>();
  const [legacy, setLegacy] = useState(readLegacy);
  const [attempt, retry] = useState(0);
  const [error, setError] = useState('');
  const [storageError, setStorageError] = useState(false);
  const savingRef = useRef(false);
  const [saving, setSaving] = useState(false);
  const [conflict, setConflict] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [generation, setGeneration] = useState(0);

  useEffect(() => {
    let active = true;
    request<Snapshot>('/data', token).then(remote => {
      if (!active) return;
      const local = draftRef.current;
      setSnapshot(remote);
      workspaceRef.current = local?.workspace ?? fromServer(remote.data);
      setWorkspace(workspaceRef.current);
      setConflict(!!local && local.revision !== remote.revision);
      setError('');
    }).catch(error => { if (active) setError(error.message); });
    return () => { active = false; };
  }, [token, key, attempt]);

  const persist = useCallback((next?: Draft) => {
    draftRef.current = next;
    setDraft(next);
    try {
      if (next) sessionStorage.setItem(key, JSON.stringify(next));
      else sessionStorage.removeItem(key);
      setStorageError(false);
    } catch { setStorageError(true); }
  }, [key]);

  async function save(local: Draft, base: Snapshot) {
    if (savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    setError('');
    try {
      const data = toServer(local.workspace, base.data);
      const { revision } = await request<{ revision: number }>('/data', token, 'PUT', { data, revision: base.revision });
      setSnapshot({ data, revision });
      const latest = draftRef.current;
      persist(latest && latest !== local ? { workspace: latest.workspace, revision } : undefined);
      if (local.imported) {
        try { localStorage.setItem(legacyKey + ':imported:' + user.id, '1'); } catch { /* optional import reminder */ }
        setLegacy(undefined);
      }
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        setConflict(true);
        setSnapshot(undefined);
      } else setError(error instanceof Error ? error.message : 'Could not save');
    } finally { savingRef.current = false; setSaving(false); }
  }

  useEffect(() => {
    if (!draft || !snapshot || conflict || error || saving) return;
    const timer = window.setTimeout(() => void save(draft, snapshot), 500);
    return () => window.clearTimeout(timer);
  }, [draft, snapshot, conflict, error, saving]);

  async function refreshConflict() {
    setRefreshing(true);
    setError('');
    try { setSnapshot(await request<Snapshot>('/data', token)); }
    catch (error) { setError(error instanceof Error ? error.message : 'Could not load server copy'); }
    finally { setRefreshing(false); }
  }

  function importLegacy() {
    if (!workspace || !legacy || !snapshot) return;
    if (!window.confirm('Import this browser’s old workspace into @' + user.username + '?')) return;
    const imported = rekey(legacy);
    const next = {
      projects: [...workspace.projects, ...imported.projects],
      tasks: [...workspace.tasks, ...imported.tasks],
      focusSessions: [...workspace.focusSessions, ...imported.focusSessions],
    };
    workspaceRef.current = next;
    setWorkspace(next);
    persist({ workspace: next, revision: snapshot.revision, imported: true });
    setGeneration(value => value + 1);
  }

  const updateWorkspace = useCallback((update: (current: Workspace) => Workspace) => {
    const current = workspaceRef.current;
    const revision = draftRef.current?.revision ?? snapshot?.revision;
    if (!current || revision === undefined) return;
    const next = update(current);
    workspaceRef.current = next;
    setWorkspace(next);
    persist({ ...draftRef.current, workspace: next, revision });
  }, [persist, snapshot]);

  useEffect(() => {
    if (!draft) return;
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [draft]);

  if (!workspace) return <main className="p-4">
    <p role="status">{error || 'Loading workspace…'}</p>
    {error && <button onClick={() => retry(value => value + 1)}>Retry</button>}
    <button className="ml-4 underline" onClick={signOut}>Sign out</button>
  </main>;

  return <div className="flex h-dvh flex-col">
    <div className="flex flex-wrap items-center gap-3 border-b border-[#E5E3DE] bg-white px-4 py-2 text-sm">
      <strong>@{user.username}</strong>
      <span role="status">{conflict ? 'Sync conflict' : saving ? 'Saving…' : error ? 'Save failed' : draft ? 'Unsaved changes' : 'Saved'}</span>
      {error && <span role="alert">{error}</span>}
      {storageError && <span role="alert">This browser could not store your draft. Keep this tab open until it saves.</span>}
      {conflict && <button className="underline" disabled={refreshing || saving} onClick={refreshConflict}>{refreshing ? 'Loading…' : 'Load latest server copy'}</button>}
      {conflict && snapshot && draft && <>
        <ul className="basis-full" aria-label="Changes if you replace the server copy">
          {describeChanges(draft.workspace, fromServer(snapshot.data)).map(({ key, added, updated, removed }) =>
            <li key={key}>{key === 'focusSessions' ? 'Focus sessions' : key}: {added} added, {updated} changed, {removed} removed</li>)}
        </ul>
        <button className="underline" disabled={saving || refreshing} onClick={() => {
          if (!window.confirm('Discard your unsaved changes and load the server copy?')) return;
          workspaceRef.current = fromServer(snapshot.data);
          setWorkspace(workspaceRef.current);
          setGeneration(value => value + 1);
          persist();
          setConflict(false);
          setError('');
        }}>Use server copy</button>
        <button className="underline" disabled={saving || refreshing} onClick={async () => {
          if (!window.confirm('Replace the server workspace with your local copy? Changes from other devices may be lost.')) return;
          setConflict(false);
          await save(draft, snapshot);
        }}>Replace with local copy</button>
      </>}
      {error && !conflict && draft && snapshot && <button className="underline" onClick={() => void save(draft, snapshot)}>Retry save</button>}
      {legacy && !readStored(legacyKey + ':imported:' + user.id) && snapshot && !draft && !conflict &&
        <button className="underline" onClick={importLegacy}>Import browser workspace</button>}
      <button className="ml-auto underline" disabled={saving || (storageError && !!draft)} onClick={signOut}>Sign out</button>
    </div>
    <App key={generation} workspace={workspace} token={token} userId={user.id} onChange={updateWorkspace} />
  </div>;
}

import React, { useEffect } from 'react';
import {
  Check,
  CheckCircle2,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
} from 'lucide-react';
import type { Task, TimerPresetId } from '../types/workspace';
import {
  TIMER_PRESETS,
  formatMinutesLabel,
  formatTimerClock,
} from '../utils/workspaceLogic';

interface FocusViewProps {
  isFullScreen: boolean;
  onToggleFullScreen: () => void;
  presetId: TimerPresetId;
  customMinutes: number;
  secondsLeft: number;
  totalDurationSeconds: number;
  isRunning: boolean;
  selectedTaskId: string | null;
  pendingTasks: Task[];
  todayFocusedMinutes: number;
  onSelectPreset: (presetId: TimerPresetId) => void;
  onChangeCustomMinutes: (minutes: number) => void;
  onSelectTask: (taskId: string | null) => void;
  onToggleRun: () => void;
  onResetTimer: () => void;
  onCompleteSessionNow: () => void;
  onMarkActiveTaskDone: (taskId: string) => void;
}

export function FocusView({
  isFullScreen,
  onToggleFullScreen,
  presetId,
  customMinutes,
  secondsLeft,
  totalDurationSeconds,
  isRunning,
  selectedTaskId,
  pendingTasks,
  todayFocusedMinutes,
  onSelectPreset,
  onChangeCustomMinutes,
  onSelectTask,
  onToggleRun,
  onResetTimer,
  onCompleteSessionNow,
  onMarkActiveTaskDone,
}: FocusViewProps) {
  useEffect(() => {
    if (!isFullScreen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onToggleFullScreen();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isFullScreen, onToggleFullScreen]);

  const activeTask = pendingTasks.find((t) => t.id === selectedTaskId) || null;
  const elapsedSeconds = Math.max(0, totalDurationSeconds - secondsLeft);
  const progress =
    totalDurationSeconds > 0 ? Math.min(100, (elapsedSeconds / totalDurationSeconds) * 100) : 0;

  const isBreakMode = presetId === 'short_break' || presetId === 'long_break';
  const circumference = 2 * Math.PI * 45; // r=45 -> ~282.74
  const dashOffset = circumference - (circumference * progress) / 100;

  const wrapperClass = isFullScreen
    ? 'fixed inset-0 z-[100] bg-[#FBFBFA] flex flex-col items-center justify-center px-5 py-8 overflow-y-auto'
    : 'max-w-2xl mx-auto flex flex-col items-center py-4 md:py-10 pb-24 md:pb-8';

  return (
    <div className={wrapperClass} data-testid="focus-view-root" data-fullscreen={isFullScreen ? 'true' : 'false'}>
      {isFullScreen && (
        <div className="fixed top-4 left-4 right-4 flex items-center justify-between">
          <button
            type="button"
            onClick={onToggleFullScreen}
            className="h-10 px-3.5 bg-white border border-[#E6E6E2] rounded-lg text-sm font-medium text-[#1C1C1A] hover:bg-[#F5F5F2] inline-flex items-center gap-2 shadow-xs"
          >
            <Minimize2 className="w-4 h-4" />
            <span>Exit Focus</span>
          </button>
          <span className="text-xs font-mono tabular-nums text-[#63635E]">
            {formatMinutesLabel(todayFocusedMinutes)} focused today
          </span>
        </div>
      )}

      {/* Mode Switcher */}
      <div className="flex flex-wrap items-center justify-center gap-1 p-1 bg-[#EFEFEA] rounded-lg mb-6">
        {TIMER_PRESETS.map((preset) => (
          <button
            key={preset.id}
            type="button"
            onClick={() => onSelectPreset(preset.id)}
            className={`h-9 px-3 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              presetId === preset.id
                ? 'bg-white text-[#1C1C1A] shadow-xs'
                : 'text-[#63635E] hover:text-[#1C1C1A]'
            }`}
          >
            {preset.label} ({preset.minutes}m)
          </button>
        ))}
        <button
          type="button"
          onClick={() => onSelectPreset('custom')}
          className={`h-9 px-3 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
            presetId === 'custom'
              ? 'bg-white text-[#1C1C1A] shadow-xs'
              : 'text-[#63635E] hover:text-[#1C1C1A]'
          }`}
        >
          Custom
        </button>
      </div>

      {presetId === 'custom' && (
        <div className="flex items-center gap-2 mb-5">
          <label htmlFor="custom-focus-minutes" className="text-xs font-medium text-[#63635E]">
            Minutes:
          </label>
          <input
            id="custom-focus-minutes"
            type="number"
            min={1}
            max={180}
            value={customMinutes}
            onChange={(e) => onChangeCustomMinutes(Number(e.target.value))}
            disabled={isRunning}
            className="w-20 h-9 px-2.5 text-sm font-mono tabular-nums bg-white border border-[#E6E6E2] rounded-lg text-center disabled:opacity-50"
          />
        </div>
      )}

      {/* Active Task Picker */}
      {!isBreakMode && (
        <div className="w-full max-w-md mb-6 space-y-2 text-center">
          <label htmlFor="focus-task-select" className="block text-xs font-medium text-[#63635E]">
            Active Task
          </label>
          <select
            id="focus-task-select"
            value={selectedTaskId || ''}
            onChange={(e) => onSelectTask(e.target.value || null)}
            className="w-full h-11 px-3 text-sm font-medium bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] focus:outline-none focus:border-[#4F46E5]"
          >
            <option value="">Open Deep Work Session (unassigned)</option>
            {pendingTasks.map((t) => (
              <option key={t.id} value={t.id}>
                {t.title} ({t.estimatedMinutes}m)
              </option>
            ))}
          </select>
        </div>
      )}

      {isBreakMode && (
        <p className="text-sm font-medium text-[#15803D] mb-6">
          Recovery break · Step away from the screen
        </p>
      )}

      {/* Countdown Ring */}
      <div className="relative flex items-center justify-center w-[240px] h-[240px] md:w-[300px] md:h-[300px] mb-8">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100" aria-hidden="true">
          <circle cx="50" cy="50" r="45" fill="none" stroke="#E6E6E2" strokeWidth="2.5" />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke={isBreakMode ? '#16A34A' : '#4F46E5'}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            className="transition-[stroke-dashoffset] duration-500 ease-linear"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6">
          <span
            data-testid="focus-timer-clock"
            className={`${
              isFullScreen ? 'text-6xl md:text-7xl' : 'text-5xl md:text-6xl'
            } font-semibold tracking-tight text-[#1C1C1A] font-mono tabular-nums`}
          >
            {formatTimerClock(secondsLeft)}
          </span>
          {activeTask && !isBreakMode && (
            <span className="mt-2 text-xs text-[#63635E] line-clamp-1 max-w-[190px]">
              {activeTask.title}
            </span>
          )}
        </div>
      </div>

      {/* Primary Timer Controls */}
      <div className="flex items-center gap-5 md:gap-7">
        <button
          type="button"
          onClick={onResetTimer}
          aria-label="Reset timer"
          title="Reset timer"
          className="min-w-[48px] min-h-[48px] rounded-full border border-[#E6E6E2] bg-white hover:bg-[#F5F5F2] text-[#63635E] hover:text-[#1C1C1A] flex items-center justify-center transition-colors"
        >
          <RotateCcw className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={onToggleRun}
          aria-label={isRunning ? 'Pause timer' : 'Start timer'}
          className={`w-16 h-16 md:w-20 md:h-20 rounded-full text-white flex items-center justify-center shadow-lg transition-transform active:scale-95 ${
            isBreakMode
              ? 'bg-[#16A34A] hover:bg-[#15803D]'
              : 'bg-[#4F46E5] hover:bg-[#4338CA]'
          }`}
        >
          {isRunning ? (
            <Pause className="w-7 h-7 fill-current" />
          ) : (
            <Play className="w-7 h-7 fill-current ml-0.5" />
          )}
        </button>

        {!isFullScreen ? (
          <button
            type="button"
            onClick={onToggleFullScreen}
            aria-label="Enter full screen focus mode"
            title="Full screen"
            className="min-w-[48px] min-h-[48px] rounded-full border border-[#E6E6E2] bg-white hover:bg-[#F5F5F2] text-[#63635E] hover:text-[#1C1C1A] flex items-center justify-center transition-colors"
          >
            <Maximize2 className="w-5 h-5" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onToggleFullScreen}
            aria-label="Exit full screen focus mode"
            title="Exit full screen"
            className="min-w-[48px] min-h-[48px] rounded-full border border-[#E6E6E2] bg-white hover:bg-[#F5F5F2] text-[#63635E] hover:text-[#1C1C1A] flex items-center justify-center transition-colors"
          >
            <Minimize2 className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Session & Task Completion Actions */}
      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        {elapsedSeconds >= 60 && !isBreakMode && (
          <button
            type="button"
            onClick={onCompleteSessionNow}
            className="h-10 px-4 rounded-lg border border-[#E6E6E2] bg-white hover:bg-[#F5F5F2] text-sm font-medium text-[#1C1C1A] inline-flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4 text-[#4F46E5]" />
            <span>Log {Math.floor(elapsedSeconds / 60)}m Session</span>
          </button>
        )}

        {activeTask && !isBreakMode && (
          <button
            type="button"
            onClick={() => onMarkActiveTaskDone(activeTask.id)}
            className="h-10 px-4 rounded-lg border border-[#E6E6E2] bg-white hover:bg-[#F0FDF4] text-sm font-medium text-[#15803D] inline-flex items-center gap-1.5"
          >
            <Check className="w-4 h-4" />
            <span>Complete Task</span>
          </button>
        )}
      </div>
    </div>
  );
}

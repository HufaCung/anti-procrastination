import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import type { Project, Task, TaskPriority } from '../types/workspace';

interface TaskModalProps {
  isOpen: boolean;
  editingTask: Task | null;
  defaultDateKey: string;
  defaultProjectId: string;
  projects: Project[];
  onClose: () => void;
  onDelete?: (taskId: string) => void;
  onSave: (payload: {
    id?: string;
    title: string;
    projectId: string;
    dueDate: string;
    scheduledTime: string;
    estimatedMinutes: number;
    priority: TaskPriority;
  }) => void;
}

const DURATION_OPTIONS = [15, 25, 30, 45, 60, 90, 120];

export function TaskModal({
  isOpen,
  editingTask,
  defaultDateKey,
  defaultProjectId,
  projects,
  onClose,
  onDelete,
  onSave,
}: TaskModalProps) {
  const [title, setTitle] = useState('');
  const [projectId, setProjectId] = useState(defaultProjectId);
  const [dueDate, setDueDate] = useState(defaultDateKey);
  const [scheduledTime, setScheduledTime] = useState('09:00');
  const [estimatedMinutes, setEstimatedMinutes] = useState(30);
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (editingTask) {
      setTitle(editingTask.title);
      setProjectId(editingTask.projectId);
      setDueDate(editingTask.dueDate);
      setScheduledTime(editingTask.scheduledTime);
      setEstimatedMinutes(editingTask.estimatedMinutes);
      setPriority(editingTask.priority);
    } else {
      setTitle('');
      setProjectId(defaultProjectId || projects[0]?.id || '');
      setDueDate(defaultDateKey);
      setScheduledTime('10:00');
      setEstimatedMinutes(30);
      setPriority('medium');
    }
    setError('');
  }, [isOpen, editingTask, defaultDateKey, defaultProjectId, projects]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = title.trim();
    if (!trimmed) {
      setError('Please enter a task title.');
      return;
    }
    onSave({
      id: editingTask?.id,
      title: trimmed,
      projectId: projectId || projects[0]?.id || '',
      dueDate,
      scheduledTime,
      estimatedMinutes: Math.max(5, Number(estimatedMinutes) || 30),
      priority,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-[#1C1C1A]/40 backdrop-blur-[2px] p-0 md:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-modal-title"
    >
      <div className="w-full md:max-w-lg bg-white border border-[#E6E6E2] rounded-t-2xl md:rounded-xl shadow-xl overflow-hidden max-h-[92vh] flex flex-col">
        <div className="md:hidden w-10 h-1 bg-[#D4D4CE] rounded-full mx-auto mt-2.5" />

        <div className="flex items-center justify-between px-5 py-4 border-b border-[#E6E6E2]">
          <h2 id="task-modal-title" className="text-base font-semibold text-[#1C1C1A]">
            {editingTask ? 'Edit Task' : 'New Task'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close task dialog"
            className="min-w-[40px] min-h-[40px] -mr-2 flex items-center justify-center rounded-lg text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F4F4F1]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto">
          <div>
            <label htmlFor="task-title-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
              Task Title
            </label>
            <input
              id="task-title-input"
              type="text"
              autoFocus
              value={title}
              onChange={(e) => {
                setTitle(e.target.value);
                if (error) setError('');
              }}
              placeholder="e.g., Finalize mobile sprint review"
              className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] focus:outline-none focus:border-[#4F46E5]"
            />
            {error && <p className="mt-1.5 text-xs text-[#DC2626]">{error}</p>}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="task-project-select" className="block text-xs font-medium text-[#63635E] mb-1.5">
                Project
              </label>
              <select
                id="task-project-select"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] focus:outline-none focus:border-[#4F46E5]"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label htmlFor="task-date-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
                Date
              </label>
              <input
                id="task-date-input"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] font-mono tabular-nums focus:outline-none focus:border-[#4F46E5]"
              />
            </div>

            <div>
              <label htmlFor="task-time-input" className="block text-xs font-medium text-[#63635E] mb-1.5">
                Scheduled Time
              </label>
              <input
                id="task-time-input"
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full h-11 px-3 text-sm bg-white border border-[#E6E6E2] rounded-lg text-[#1C1C1A] font-mono tabular-nums focus:outline-none focus:border-[#4F46E5]"
              />
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-[#63635E] mb-1.5">
              Time Estimate
            </span>
            <div className="flex flex-wrap gap-1.5">
              {DURATION_OPTIONS.map((mins) => (
                <button
                  key={mins}
                  type="button"
                  onClick={() => setEstimatedMinutes(mins)}
                  className={`h-9 px-3 rounded-lg text-xs font-mono tabular-nums font-medium border transition-colors ${
                    estimatedMinutes === mins
                      ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                      : 'bg-[#F5F5F2] border-[#E6E6E2] text-[#1C1C1A] hover:bg-[#EAEAE4]'
                  }`}
                >
                  {mins}m
                </button>
              ))}
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-[#63635E] mb-1.5">Priority</span>
            <div className="grid grid-cols-3 gap-2">
              {(['low', 'medium', 'high'] as TaskPriority[]).map((level) => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setPriority(level)}
                  className={`h-10 rounded-lg text-xs font-medium capitalize border transition-colors ${
                    priority === level
                      ? 'bg-[#1C1C1A] border-[#1C1C1A] text-white'
                      : 'bg-white border-[#E6E6E2] text-[#63635E] hover:text-[#1C1C1A]'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-2 flex items-center justify-between gap-2.5 border-t border-[#E6E6E2]">
            {editingTask && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  onDelete(editingTask.id);
                  onClose();
                }}
                className="h-10 px-3 rounded-lg text-sm font-medium text-[#DC2626] hover:bg-[#FEF2F2] transition-colors"
              >
                Delete
              </button>
            ) : (
              <div />
            )}
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="h-10 px-4 rounded-lg border border-[#E6E6E2] text-sm font-medium text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F5F5F2] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="h-10 px-5 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-sm font-medium transition-colors"
              >
                {editingTask ? 'Save Changes' : 'Create Task'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

import React from 'react';
import { Menu, Plus, Search, Timer, X } from 'lucide-react';
import type { ViewId } from '../types/workspace';
import { formatTimerClock } from '../utils/workspaceLogic';
import { NAVIGATION_ITEMS } from './Sidebar';

interface HeaderProps {
  currentView: ViewId;
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onOpenMobileMenu: () => void;
  onOpenNewTask: () => void;
  isTimerActiveOrPaused: boolean;
  timerSecondsLeft: number;
  isTimerRunning: boolean;
  onJumpToFocus: () => void;
}

export function Header({
  currentView,
  searchQuery,
  onSearchChange,
  onOpenMobileMenu,
  onOpenNewTask,
  isTimerActiveOrPaused,
  timerSecondsLeft,
  isTimerRunning,
  onJumpToFocus,
}: HeaderProps) {
  const activeTitle = NAVIGATION_ITEMS.find((n) => n.id === currentView)?.name || 'TinyDo';

  return (
    <header className="h-[52px] md:h-[64px] px-3 md:px-8 border-b border-[#E6E6E2] bg-white/95 backdrop-blur-sm flex items-center justify-between gap-3 shrink-0 sticky top-0 z-20">
      <div className="flex items-center gap-2 min-w-0">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          aria-label="Open navigation menu"
          className="md:hidden min-w-[44px] min-h-[44px] -ml-1.5 flex items-center justify-center rounded-lg text-[#1C1C1A] hover:bg-[#F4F4F1] transition-colors shrink-0"
        >
          <Menu className="w-5 h-5" />
        </button>
        <h1 className="text-base md:text-xl font-semibold tracking-tight text-[#1C1C1A] truncate">
          {activeTitle}
        </h1>
      </div>

      <div className="flex items-center gap-2 md:gap-3 shrink-0">
        <div className="hidden lg:flex items-center relative w-60">
          <Search className="w-4 h-4 text-[#7A7A74] absolute left-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Filter tasks..."
            aria-label="Filter tasks"
            className="w-full h-9 pl-9 pr-8 text-sm bg-[#F5F5F2] border border-[#E6E6E2] rounded-lg text-[#1C1C1A] placeholder:text-[#7A7A74] focus:outline-none focus:border-[#4F46E5] focus:bg-white transition-colors"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onSearchChange('')}
              aria-label="Clear task search"
              className="absolute right-2 p-1 text-[#63635E] hover:text-[#1C1C1A]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {isTimerActiveOrPaused && currentView !== 'focus' && (
          <button
            type="button"
            onClick={onJumpToFocus}
            aria-label={`Return to active focus timer (${formatTimerClock(timerSecondsLeft)})`}
            className="h-9 px-3 rounded-lg border border-[#E6E6E2] bg-[#F5F5F2] hover:bg-[#EAEAE4] text-[#1C1C1A] text-xs md:text-sm font-medium flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            <Timer
              className={`w-4 h-4 ${isTimerRunning ? 'text-[#4F46E5]' : 'text-[#63635E]'}`}
            />
            <span className="font-mono tabular-nums">{formatTimerClock(timerSecondsLeft)}</span>
          </button>
        )}

        <button
          type="button"
          onClick={onOpenNewTask}
          className="h-9 md:h-10 px-3 md:px-4 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-xs md:text-sm font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          <Plus className="w-4 h-4 shrink-0" />
          <span>New Task</span>
        </button>
      </div>
    </header>
  );
}

import React, { useMemo, useState } from 'react';
import { Check, ChevronLeft, ChevronRight, Play, Plus } from 'lucide-react';
import type { Project, Task } from '../types/workspace';
import { buildCalendarMonth, formatTime12h } from '../utils/workspaceLogic';

interface CalendarViewProps {
  tasks: Task[];
  projects: Project[];
  todayKey: string;
  onToggleTask: (taskId: string) => void;
  onStartFocusTask: (taskId: string) => void;
  onAddTaskOnDate: (dateKey: string) => void;
}

const MONTH_NAMES = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

export function CalendarView({
  tasks,
  projects,
  todayKey,
  onToggleTask,
  onStartFocusTask,
  onAddTaskOnDate,
}: CalendarViewProps) {
  const [todayYear, todayMonth] = todayKey.split('-').map(Number);
  const [viewYear, setViewYear] = useState(todayYear);
  const [viewMonthIndex, setViewMonthIndex] = useState(todayMonth - 1);
  const [selectedDateKey, setSelectedDateKey] = useState(todayKey);

  const projectById = useMemo(() => {
    const map = new Map<string, Project>();
    projects.forEach((p) => map.set(p.id, p));
    return map;
  }, [projects]);

  const cells = useMemo(
    () => buildCalendarMonth(viewYear, viewMonthIndex, tasks, todayKey),
    [viewYear, viewMonthIndex, tasks, todayKey]
  );

  const selectedDayTasks = useMemo(
    () =>
      tasks
        .filter((t) => t.dueDate === selectedDateKey)
        .sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime)),
    [tasks, selectedDateKey]
  );

  const goPrevMonth = () => {
    if (viewMonthIndex === 0) {
      setViewYear((y) => y - 1);
      setViewMonthIndex(11);
    } else {
      setViewMonthIndex((m) => m - 1);
    }
  };

  const goNextMonth = () => {
    if (viewMonthIndex === 11) {
      setViewYear((y) => y + 1);
      setViewMonthIndex(0);
    } else {
      setViewMonthIndex((m) => m + 1);
    }
  };

  const goToday = () => {
    setViewYear(todayYear);
    setViewMonthIndex(todayMonth - 1);
    setSelectedDateKey(todayKey);
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 pb-20 md:pb-6 items-start">
      {/* Month Calendar Grid */}
      <section className="lg:col-span-2 bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3.5 border-b border-[#E6E6E2]">
          <h2 className="text-base md:text-lg font-semibold text-[#1C1C1A]">
            {MONTH_NAMES[viewMonthIndex]} {viewYear}
          </h2>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={goPrevMonth}
              aria-label="Previous month"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg border border-[#E6E6E2] text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F5F5F2]"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={goToday}
              className="h-10 px-3 rounded-lg border border-[#E6E6E2] text-xs md:text-sm font-medium text-[#1C1C1A] hover:bg-[#F5F5F2]"
            >
              Today
            </button>
            <button
              type="button"
              onClick={goNextMonth}
              aria-label="Next month"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center rounded-lg border border-[#E6E6E2] text-[#63635E] hover:text-[#1C1C1A] hover:bg-[#F5F5F2]"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 border-b border-[#E6E6E2] bg-[#FAF9F6]">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
            <div key={d} className="py-2 text-center text-[11px] font-semibold text-[#63635E]">
              {d}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7">
          {cells.map((cell) => {
            const isSelected = cell.dateKey === selectedDateKey;
            const pendingCount = cell.tasks.filter((t) => !t.completed).length;
            return (
              <button
                key={cell.dateKey}
                type="button"
                onClick={() => setSelectedDateKey(cell.dateKey)}
                aria-label={`${cell.dateKey}, ${cell.tasks.length} tasks`}
                aria-pressed={isSelected}
                className={`min-h-[60px] md:min-h-[88px] p-1.5 md:p-2 border-b border-r border-[#EFEFEA] text-left flex flex-col justify-between transition-colors ${
                  isSelected
                    ? 'bg-[#EEF2FF]'
                    : cell.inCurrentMonth
                      ? 'bg-white hover:bg-[#FAF9F6]'
                      : 'bg-[#FAF9F6] text-[#9C9C94]'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span
                    className={`w-6 h-6 rounded-full text-xs font-mono tabular-nums flex items-center justify-center ${
                      cell.isToday
                        ? 'bg-[#4F46E5] text-white font-semibold'
                        : isSelected
                          ? 'text-[#4F46E5] font-semibold'
                          : cell.inCurrentMonth
                            ? 'text-[#1C1C1A]'
                            : 'text-[#9C9C94]'
                    }`}
                  >
                    {cell.dayNumber}
                  </span>
                  {cell.tasks.length > 0 && (
                    <span className="md:hidden text-[10px] font-mono tabular-nums font-semibold text-[#4F46E5]">
                      {cell.tasks.length}
                    </span>
                  )}
                </div>

                <div className="hidden md:block space-y-1 w-full mt-1">
                  {cell.tasks.slice(0, 2).map((task) => (
                    <p
                      key={task.id}
                      className={`text-[11px] truncate ${
                        task.completed ? 'line-through text-[#9C9C94]' : 'text-[#1C1C1A]'
                      }`}
                    >
                      {task.title}
                    </p>
                  ))}
                  {cell.tasks.length > 2 && (
                    <p className="text-[10px] text-[#63635E] font-mono">
                      +{cell.tasks.length - 2} more
                    </p>
                  )}
                </div>

                {pendingCount > 0 && (
                  <div className="md:hidden w-full flex justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#4F46E5]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Selected Day Agenda */}
      <section className="bg-white border border-[#E6E6E2] rounded-xl overflow-hidden">
        <div className="px-4 py-3.5 border-b border-[#E6E6E2] flex items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold text-[#1C1C1A]">Day Schedule</h3>
            <p className="text-xs text-[#63635E] font-mono tabular-nums mt-0.5">
              {selectedDateKey === todayKey ? `${selectedDateKey} (Today)` : selectedDateKey}
            </p>
          </div>
          <button
            type="button"
            onClick={() => onAddTaskOnDate(selectedDateKey)}
            className="h-9 px-3 rounded-lg bg-[#4F46E5] hover:bg-[#4338CA] text-white text-xs font-medium inline-flex items-center gap-1 whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Schedule</span>
          </button>
        </div>

        {selectedDayTasks.length === 0 ? (
          <div className="p-8 text-center space-y-2">
            <p className="text-sm font-medium text-[#1C1C1A]">No tasks scheduled</p>
            <p className="text-xs text-[#63635E]">
              Block time on {selectedDateKey} to keep your schedule structured.
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-[#EFEFEA]">
            {selectedDayTasks.map((task) => {
              const proj = projectById.get(task.projectId);
              return (
                <li key={task.id} className="p-3.5 flex items-start gap-2.5">
                  <button
                    type="button"
                    onClick={() => onToggleTask(task.id)}
                    aria-label={
                      task.completed
                        ? `Mark "${task.title}" incomplete`
                        : `Mark "${task.title}" complete`
                    }
                    className="min-w-[36px] min-h-[36px] -ml-1 flex items-center justify-center shrink-0"
                  >
                    <span
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        task.completed
                          ? 'bg-[#4F46E5] border-[#4F46E5] text-white'
                          : 'border-[#C9C9C2] bg-white'
                      }`}
                    >
                      {task.completed && <Check className="w-2.5 h-2.5" />}
                    </span>
                  </button>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-sm font-medium ${
                        task.completed ? 'line-through text-[#7A7A74]' : 'text-[#1C1C1A]'
                      }`}
                    >
                      {task.title}
                    </p>
                    <p className="text-xs text-[#63635E] mt-1 font-mono tabular-nums">
                      {formatTime12h(task.scheduledTime)} · {task.estimatedMinutes}m ·{' '}
                      {proj?.name || 'Workspace'}
                    </p>
                  </div>
                  {!task.completed && (
                    <button
                      type="button"
                      onClick={() => onStartFocusTask(task.id)}
                      aria-label={`Focus on "${task.title}"`}
                      className="min-w-[36px] min-h-[36px] rounded-lg text-[#4F46E5] hover:bg-[#EEF2FF] flex items-center justify-center shrink-0"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

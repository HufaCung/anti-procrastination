import { useEffect, useState, type FormEvent } from 'react';
import type { Team } from '../../../backend/src/types';
import { request } from '../data/api';

export function TeamsView({ token, userId }: { token: string; userId: string }) {
  const [teams, setTeams] = useState<Team[]>([]);
  const [selected, setSelected] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const team = teams.find(team => team.id === selected) ?? teams[0];
  const endpoint = team ? '/teams/' + encodeURIComponent(team.id) : '';
  const owner = team?.ownerId === userId;

  useEffect(() => {
    let active = true;
    request<{ teams: Team[] }>('/teams', token)
      .then(result => { if (active) setTeams(result.teams); })
      .catch(error => { if (active) setError(error.message); });
    return () => { active = false; };
  }, [token]);

  async function update(path: string, method: string, data?: unknown) {
    setBusy(true);
    setError('');
    try {
      await request(path, token, method, data);
      const result = await request<{ teams: Team[] }>('/teams', token);
      setTeams(result.teams);
      return true;
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Team request failed');
      return false;
    } finally { setBusy(false); }
  }

  async function submit(event: FormEvent<HTMLFormElement>, path: string) {
    event.preventDefault();
    const form = event.currentTarget;
    if (await update(path, 'POST', Object.fromEntries(new FormData(form)))) form.reset();
  }

  return <section className="mx-auto max-w-3xl space-y-4">
    <h1 className="text-2xl font-bold">Teams</h1>
    {error && <p role="alert">{error}</p>}
    <fieldset disabled={busy} className="space-y-4">
      <form className="flex flex-wrap gap-2" onSubmit={event => void submit(event, '/teams')}>
        <input aria-label="New team name" className="rounded border p-2" name="name" placeholder="New team name" maxLength={80} required />
        <button className="rounded border px-3">Create team</button>
      </form>
      {team && <>
        <label>Team <select className="rounded border p-2" value={team.id} onChange={event => setSelected(event.target.value)}>
          {teams.map(team => <option key={team.id} value={team.id}>{team.name}</option>)}
        </select></label>
        <div className="rounded border bg-white p-4">
          <h2 className="font-semibold">Members</h2>
          <ul className="mb-3">{team.members.map(member => <li key={member.userId}>{member.name} (@{member.username}) · {member.role}</li>)}</ul>
          {owner && <form className="flex flex-wrap gap-2" onSubmit={event => void submit(event, endpoint + '/members')}>
            <input className="rounded border p-2" aria-label="Member username" name="username" placeholder="Member username" required />
            <button className="rounded border px-3">Add member</button>
          </form>}
        </div>
        <div className="rounded border bg-white p-4">
          <h2 className="font-semibold">Tasks</h2>
          <ul className="mb-3 space-y-2">{team.tasks.map(task => <li key={task.id}>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={task.done} onChange={event => void update(endpoint + '/tasks/' + encodeURIComponent(task.id), 'PATCH', { done: event.target.checked })} />
              {task.title}
              {task.assigneeId && <small>{team.members.find(member => member.userId === task.assigneeId)?.name}</small>}
            </label>
          </li>)}</ul>
          <form className="flex flex-wrap gap-2" onSubmit={event => void submit(event, endpoint + '/tasks')}>
            <input className="rounded border p-2" aria-label="Task title" placeholder="Task title" name="title" maxLength={160} required />
            <select className="rounded border p-2" name="assigneeId" aria-label="Assignee">
              <option value="">Unassigned</option>
              {team.members.map(member => <option key={member.userId} value={member.userId}>{member.name}</option>)}
            </select>
            <button className="rounded border px-3">Add task</button>
          </form>
        </div>
        {owner && <button className="underline" onClick={() => {
          if (window.confirm('Delete this team and all its tasks?')) void update(endpoint, 'DELETE');
        }}>Delete team</button>}
      </>}
    </fieldset>
  </section>;
}

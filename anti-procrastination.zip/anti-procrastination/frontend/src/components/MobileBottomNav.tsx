import React from 'react';
import { CalendarDays, FolderKanban, LayoutDashboard, Timer } from 'lucide-react';
import type { ViewId } from '../types/workspace';

interface MobileBottomNavProps {
  currentView: ViewId;
  onSelectView: (view: ViewId) => void;
}

const MOBILE_TABS: Array<{
  id: ViewId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'dashboard', label: 'Today', icon: LayoutDashboard },
  { id: 'projects', label: 'Projects', icon: FolderKanban },
  { id: 'calendar', label: 'Calendar', icon: CalendarDays },
  { id: 'focus', label: 'Focus', icon: Timer },
];

export function MobileBottomNav({ currentView, onSelectView }: MobileBottomNavProps) {
  return (
    <nav
      aria-label="Mobile quick navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-[56px] bg-white/95 backdrop-blur-md border-t border-[#E6E6E2] grid grid-cols-4 items-center"
    >
      {MOBILE_TABS.map((tab) => {
        const Icon = tab.icon;
        const active = currentView === tab.id;
        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onSelectView(tab.id)}
            aria-current={active ? 'page' : undefined}
            className={`h-full min-h-[44px] flex flex-col items-center justify-center gap-0.5 transition-colors whitespace-nowrap ${
              active ? 'text-[#4F46E5]' : 'text-[#63635E] hover:text-[#1C1C1A]'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[11px] font-medium tracking-tight">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

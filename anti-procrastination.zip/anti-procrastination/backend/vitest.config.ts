import { defineConfig } from 'vitest/config';

const testDatabase = process.env.TINYDO_TEST_DATABASE_URL || '';
if (testDatabase && !/^postgresql:\/\/tinydo_test:[0-9a-f-]+@127\.0\.0\.1:\d+\/postgres$/.test(testDatabase)) {
  throw new Error('PostgreSQL tests require the isolated loopback cluster');
}

export default defineConfig({
  test: {
    include: ['src/**/*.test.ts'],
    testTimeout: 20_000,
    maxWorkers: 1,
    env: { DATABASE_URL: testDatabase, REQUIRE_DATABASE_URL: testDatabase ? 'true' : 'false', DATABASE_PATH: ':memory:', NODE_ENV: 'test' },
  },
});

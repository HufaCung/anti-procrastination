import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { teamsDb } from '../db/database.js';
import { authMiddleware, type AuthenticatedRequest } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/async-handler.js';
import type { Team } from '../types.js';

export const teamsRouter = Router();
teamsRouter.use(authMiddleware);

teamsRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res) => {
  res.json({ teams: await teamsDb.list(req.user!.id) });
}));

teamsRouter.post('/', asyncHandler(async (req: AuthenticatedRequest, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const color = req.body?.color ?? '#4f7d64';
  if (!name || name.length > 80 || typeof color !== 'string' || !/^#[0-9a-f]{6}$/i.test(color)) {
    res.status(400).json({ error: 'Valid team name and color are required' });
    return;
  }
  const team: Team = {
    id: 'team_' + randomUUID(), name, color, ownerId: req.user!.id,
    createdAt: new Date().toISOString(), members: [], tasks: [],
  };
  await teamsDb.create(team, team.ownerId);
  res.status(201).json({ team });
}));

teamsRouter.post('/:id/members', asyncHandler(async (req: AuthenticatedRequest, res) => {
  const username = typeof req.body?.username === 'string' ? req.body.username.trim() : '';
  if (!username || username.length > 100) {
    res.status(400).json({ error: 'Username is required' });
    return;
  }
  const result = await teamsDb.addMember(String(req.params.id), req.user!.id, username);
  if (result === 'missing') { res.status(404).json({ error: 'Account not found' }); return; }
  if (result === 'forbidden') { res.status(403).json({ error: 'Only the owner can invite members' }); return; }
  res.json({ success: true });
}));

teamsRouter.post('/:id/tasks', asyncHandler(async (req: AuthenticatedRequest, res) => {
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const assigneeId = req.body?.assigneeId || undefined;
  if (!title || title.length > 160 || (assigneeId !== undefined && (typeof assigneeId !== 'string' || assigneeId.length > 100))) {
    res.status(400).json({ error: 'Invalid task title or assignee' });
    return;
  }
  const teamId = String(req.params.id);
  const createdBy = req.user!.id;
  const task = { id: 'tt_' + randomUUID(), teamId, title, assigneeId, done: false, createdBy, createdAt: new Date().toISOString() };
  const result = await teamsDb.addTask(teamId, createdBy, task);
  if (result === 'forbidden') { res.status(403).json({ error: 'Not a team member' }); return; }
  if (result === 'invalid_assignee') { res.status(400).json({ error: 'Assignee must belong to this team' }); return; }
  res.status(201).json({ task });
}));

teamsRouter.patch('/:id/tasks/:taskId', asyncHandler(async (req: AuthenticatedRequest, res) => {
  if (typeof req.body?.done !== 'boolean') {
    res.status(400).json({ error: 'done must be a boolean' });
    return;
  }
  if (!await teamsDb.toggleTask(String(req.params.id), String(req.params.taskId), req.user!.id, req.body.done)) {
    res.status(404).json({ error: 'Task not found' });
    return;
  }
  res.json({ success: true });
}));

teamsRouter.delete('/:id', asyncHandler(async (req: AuthenticatedRequest, res) => {
  if (!await teamsDb.remove(String(req.params.id), req.user!.id)) {
    res.status(403).json({ error: 'Only the owner can delete this team' });
    return;
  }
  res.json({ success: true });
}));

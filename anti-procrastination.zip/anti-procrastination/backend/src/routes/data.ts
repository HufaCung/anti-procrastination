import { isDataValidationError } from '../db/errors.js';
import { asyncHandler } from '../middleware/async-handler.js';
import { Router, type Response } from 'express';
import { getAppDataSnapshot, syncAppData } from '../db/database.js';
import { authMiddleware, type AuthenticatedRequest } from '../middleware/auth.js';
import type { AppData } from '../types.js';

function dashboardMetadataIsValid(value: unknown): boolean {
  const record = (input: unknown): input is Record<string, unknown> =>
    !!input && typeof input === 'object' && !Array.isArray(input);
  const number = (input: unknown) => typeof input === 'number' && Number.isFinite(input) && input >= 0;
  if (!record(value) || !record(value.projects) || !record(value.tasks) || !record(value.sessions)) return false;
  return Object.values(value.projects).every(item => record(item) &&
    ['On Track', 'At Risk', 'Completed'].includes(String(item.status)) && number(item.weeklyTargetMinutes)) &&
    Object.values(value.tasks).every(item => record(item) &&
      typeof item.scheduledTime === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$|^$/.test(item.scheduledTime) &&
      number(item.loggedMinutes) && ['low', 'medium', 'high'].includes(String(item.priority))) &&
    Object.values(value.sessions).every(item => record(item) && typeof item.date === 'string' &&
      /^\d{4}-\d{2}-\d{2}$/.test(item.date) &&
      ['pomodoro', 'deep', 'short_break', 'long_break', 'custom'].includes(String(item.mode)));
}

export const dataRouter = Router();

dataRouter.use(authMiddleware);

// GET /api/data - Retrieve all user data
dataRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  res.json(await getAppDataSnapshot(user.id));
}));

// PUT /api/data - Full sync user data
dataRouter.put('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const data = req.body?.data as AppData;
  const display = data?.meta?.dashboard;
  if (display !== undefined && (!display || !dashboardMetadataIsValid(display))) {
    res.status(400).json({ error: 'Invalid dashboard metadata' });
    return;
  }

  if (!data || !Array.isArray(data.projects) || !Array.isArray(data.tasks) || !Array.isArray(data.sessions) || !Number.isSafeInteger(req.body.revision) || req.body.revision < 0) {
    res.status(400).json({ error: 'data and revision are required' });
    return;
  }

  try {
    const revision = await syncAppData(user.id, data, req.body.revision);
    if (revision === null) {
      res.status(409).json({ error: 'Data changed on another device' });
      return;
    }
    res.json({ success: true, revision });
  } catch (error) {
    if (!isDataValidationError(error)) throw error;
    res.status(400).json({ error: 'Invalid data or record ownership' });
  }
}));

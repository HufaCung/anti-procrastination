import { asyncHandler } from '../middleware/async-handler.js';
import { Router, type Response } from 'express';
import { settingsDb, defaultSettings } from '../db/database.js';
import { authMiddleware, type AuthenticatedRequest } from '../middleware/auth.js';
import type { Settings } from '../types.js';

export const settingsRouter = Router();

settingsRouter.use(authMiddleware);

// GET /api/settings
settingsRouter.get('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const settings = await settingsDb.get(user.id);
  res.json({ settings });
}));

// PATCH /api/settings
settingsRouter.patch('/', asyncHandler(async (req: AuthenticatedRequest, res: Response) => {
  const user = req.user!;
  const current = await settingsDb.get(user.id);
  const patch = req.body ?? {};
  const updated: Settings = { ...current, userId: user.id };
  if (patch.theme === 'light' || patch.theme === 'dark') updated.theme = patch.theme;
  if (typeof patch.dailyGoalMin === 'number' && Number.isFinite(patch.dailyGoalMin) && patch.dailyGoalMin >= 30 && patch.dailyGoalMin <= 480) updated.dailyGoalMin = Math.round(patch.dailyGoalMin);
  if (patch.defaultTaskMin === 10 || patch.defaultTaskMin === 15) updated.defaultTaskMin = patch.defaultTaskMin;
  if (typeof patch.timeZone === 'string' && patch.timeZone.trim().length > 0 && patch.timeZone.length <= 64) updated.timeZone = patch.timeZone.trim();
  if (patch.weekStart === 'mon' || patch.weekStart === 'sun') updated.weekStart = patch.weekStart;
  if (typeof patch.autoReplan === 'boolean') updated.autoReplan = patch.autoReplan;
  if (typeof patch.deadlineAlerts === 'boolean') updated.deadlineAlerts = patch.deadlineAlerts;
  if (typeof patch.weeklyDigest === 'boolean') updated.weeklyDigest = patch.weeklyDigest;
  if (typeof patch.focusSound === 'boolean') updated.focusSound = patch.focusSound;

  await settingsDb.save(updated);
  res.json({ settings: updated });
}));

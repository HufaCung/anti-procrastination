import { afterAll, beforeAll, expect, it } from 'vitest';
import type { AddressInfo } from 'node:net';
import { app } from './server.js';

let server: ReturnType<typeof app.listen>;
let url: string;
const password = 'local-test-password';

beforeAll(async () => {
  await new Promise<void>((resolve, reject) => {
    server = app.listen(0, '127.0.0.1', () => resolve()).once('error', reject);
  });
  url = 'http://127.0.0.1:' + (server.address() as AddressInfo).port + '/api';
});
afterAll(async () => {
  if (server) await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
});

async function call(path: string, method = 'GET', body?: unknown, token?: string) {
  const response = await fetch(url + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  return { status: response.status, body: await response.json(), retryAfter: response.headers.get('retry-after') };
}

it('keeps assigned team tasks when a member leaves and transfers ownership deterministically', async () => {
  const signup = async (username: string) => (await call('/auth/signup', 'POST', { username, password })).body;
  const owner = await signup('team-owner');
  const member = await signup('team-member');
  const outsider = await signup('team-outsider');
  const team = (await call('/teams', 'POST', { name: 'Shared' }, owner.token)).body.team;
  const path = '/teams/' + team.id;
  expect((await call(path + '/tasks', 'POST', { title: 'Bad assignment', assigneeId: outsider.user.id }, owner.token)).status).toBe(400);
  expect((await call(path + '/tasks', 'POST', { title: 'No access' }, outsider.token)).status).toBe(403);
  expect((await call(path + '/members', 'POST', { username: member.user.username }, owner.token)).status).toBe(200);
  const memberTask = await call(path + '/tasks', 'POST', { title: 'Member task', assigneeId: owner.user.id }, member.token);
  const ownerTask = await call(path + '/tasks', 'POST', { title: 'Owner task', assigneeId: member.user.id }, owner.token);
  expect(memberTask.status).toBe(201);
  expect(ownerTask.status).toBe(201);
  expect((await call('/auth/account', 'DELETE', { password }, owner.token)).status).toBe(200);
  const surviving = (await call('/teams', 'GET', undefined, member.token)).body.teams[0];
  expect(surviving.ownerId).toBe(member.user.id);
  expect(surviving.members).toMatchObject([{ userId: member.user.id, role: 'owner' }]);
  expect(surviving.tasks).toHaveLength(2);
  expect(surviving.tasks.find((task: { id: string }) => task.id === ownerTask.body.task.id).createdBy).toBeUndefined();
  expect(surviving.tasks.find((task: { id: string }) => task.id === memberTask.body.task.id).assigneeId).toBeUndefined();
});

it('round-trips dashboard fields and rejects a stale save without overwriting the first save', async () => {
  expect((await call('/ready')).body).toEqual({ status: 'ready' });
  const { token } = (await call('/auth/signup', 'POST', { username: 'dashboard-sync', password })).body;
  const snapshot = (await call('/data', 'GET', undefined, token)).body;
  const dashboard = { projects: {}, tasks: { task: { scheduledTime: '10:00', loggedMinutes: 30, priority: 'low' } }, sessions: {} };
  snapshot.data.meta.dashboard = dashboard;
  expect((await call('/data', 'PUT', snapshot, token)).status).toBe(200);
  expect((await call('/data', 'PUT', snapshot, token)).status).toBe(409);
  const current = (await call('/data', 'GET', undefined, token)).body;
  expect(current.data.meta.dashboard).toEqual(dashboard);
  current.data.meta.dashboard.tasks.task.scheduledTime = '99:01';
  expect((await call('/data', 'PUT', current, token)).status).toBe(400);
  expect((await call('/data', 'GET', undefined, token)).body.data.meta.dashboard).toEqual(dashboard);
});

it('limits repeated login requests', async () => {
  for (let attempt = 0; attempt < 20; attempt++) {
    expect((await call('/auth/login', 'POST', { username: 'absent', password })).status).toBe(401);
  }
  const blocked = await call('/auth/login', 'POST', { username: 'absent', password });
  expect(blocked.status).toBe(429);
  expect(Number(blocked.retryAfter)).toBeGreaterThan(0);
});

import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { defaultSettings, defaultMeta } from './defaults.js';
export { defaultSettings, defaultMeta } from './defaults.js';
import { DataValidationError } from './errors.js';
import type { AppData, FocusSession, Meta, Project, Settings, Task, Team, User } from '../types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dataDir = process.env.DATA_DIR || path.resolve(__dirname, '../../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = process.env.DATABASE_PATH || path.join(dataDir, 'tinydo.db');
export const db = new Database(dbPath);

// Enable WAL mode & foreign keys
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      avatar TEXT,
      password_changed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      color TEXT NOT NULL,
      description TEXT,
      priority TEXT NOT NULL,
      due_date TEXT NOT NULL,
      created_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
      section TEXT NOT NULL,
      title TEXT NOT NULL,
      estimate_min INTEGER NOT NULL,
      status TEXT NOT NULL,
      task_order INTEGER NOT NULL,
      scheduled_for TEXT,
      completed_at TEXT,
      created_at TEXT NOT NULL,
      replanned_from TEXT
    );

    CREATE TABLE IF NOT EXISTS focus_sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      task_id TEXT,
      project_id TEXT,
      started_at TEXT NOT NULL,
      ended_at TEXT NOT NULL,
      minutes INTEGER NOT NULL,
      completed_task INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS settings (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      theme TEXT NOT NULL DEFAULT 'light',
      daily_goal_min INTEGER NOT NULL DEFAULT 180,
      default_task_min INTEGER NOT NULL DEFAULT 15,
      time_zone TEXT NOT NULL DEFAULT 'Asia/Ho_Chi_Minh',
      week_start TEXT NOT NULL DEFAULT 'mon',
      auto_replan INTEGER NOT NULL DEFAULT 1,
      deadline_alerts INTEGER NOT NULL DEFAULT 1,
      weekly_digest INTEGER NOT NULL DEFAULT 0,
      focus_sound INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS meta (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      last_auto_replan_at TEXT,
      shown_alerts TEXT,
      snoozed_alerts TEXT,
      timer TEXT,
      parking TEXT,
      last_replan TEXT,
      onboarded INTEGER DEFAULT 0
    );

    CREATE INDEX IF NOT EXISTS idx_projects_user ON projects(user_id);
    CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id);
    CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON focus_sessions(user_id);

    CREATE TABLE IF NOT EXISTS data_revisions (user_id TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE IF NOT EXISTS teams (id TEXT PRIMARY KEY,name TEXT NOT NULL,color TEXT NOT NULL,owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS team_members (team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,role TEXT NOT NULL,joined_at TEXT NOT NULL,PRIMARY KEY(team_id,user_id));
    CREATE TABLE IF NOT EXISTS team_tasks (id TEXT PRIMARY KEY,team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,title TEXT NOT NULL,done INTEGER NOT NULL DEFAULT 0,assignee_id TEXT REFERENCES users(id) ON DELETE SET NULL,created_by TEXT REFERENCES users(id) ON DELETE SET NULL,created_at TEXT NOT NULL);
  `);
  db.transaction(() => {
    const metaColumns = db.prepare('PRAGMA table_info(meta)').all() as { name: string }[];
    if (!metaColumns.some(column => column.name === 'dashboard')) db.exec('ALTER TABLE meta ADD COLUMN dashboard TEXT');
    const teamTaskColumns = db.prepare('PRAGMA table_info(team_tasks)').all() as { name: string; notnull: number }[];
    if (teamTaskColumns.some(column => column.name === 'created_by' && column.notnull)) {
      db.exec(`
        ALTER TABLE team_tasks RENAME TO team_tasks_legacy;
        CREATE TABLE team_tasks (
          id TEXT PRIMARY KEY, team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
          title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0,
          assignee_id TEXT REFERENCES users(id) ON DELETE SET NULL,
          created_by TEXT REFERENCES users(id) ON DELETE SET NULL, created_at TEXT NOT NULL
        );
        INSERT INTO team_tasks SELECT * FROM team_tasks_legacy;
        DROP TABLE team_tasks_legacy;
        UPDATE team_tasks SET assignee_id = NULL WHERE assignee_id IS NOT NULL AND NOT EXISTS (
          SELECT 1 FROM team_members WHERE team_id = team_tasks.team_id AND user_id = team_tasks.assignee_id
        );
      `);
    }
    db.exec('CREATE INDEX IF NOT EXISTS idx_team_members_user ON team_members(user_id)');
    db.exec('CREATE INDEX IF NOT EXISTS idx_team_tasks_team ON team_tasks(team_id)');
  }).immediate();
  const userColumns = db.prepare('PRAGMA table_info(users)').all() as { name: string }[];
  if (!userColumns.some((column) => column.name === 'auth_version')) db.exec('ALTER TABLE users ADD COLUMN auth_version INTEGER NOT NULL DEFAULT 0 CHECK (auth_version >= 0)');
  if (!userColumns.some((column) => column.name === 'role')) db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin'))");
  if (!userColumns.some((column) => column.name === 'username')) db.exec('ALTER TABLE users RENAME COLUMN email TO username');
  const taskColumns = db.prepare('PRAGMA table_info(tasks)').all() as { name: string }[];
  if (!taskColumns.some((column) => column.name === 'due_date')) db.exec('ALTER TABLE tasks ADD COLUMN due_date TEXT');
  if (!taskColumns.some((column) => column.name === 'subtasks')) db.exec('ALTER TABLE tasks ADD COLUMN subtasks TEXT');
  for (const table of ['projects', 'tasks', 'focus_sessions', 'settings', 'meta']) {
    for (const [operation, row] of [['INSERT', 'NEW'], ['UPDATE', 'NEW'], ['DELETE', 'OLD']]) {
      db.exec(`CREATE TRIGGER IF NOT EXISTS revision_${table}_${operation.toLowerCase()}
        AFTER ${operation} ON ${table} BEGIN
          INSERT INTO data_revisions (user_id, revision) VALUES (${row}.user_id, 1)
          ON CONFLICT(user_id) DO UPDATE SET revision = revision + 1;
        END`);
    }
  }
  // Preserve legacy focus history while removing references that could not pass
  // the ownership checks now enforced on every session write.
  db.exec(`UPDATE focus_sessions SET task_id = NULL
    WHERE task_id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM tasks t WHERE t.id = focus_sessions.task_id AND t.user_id = focus_sessions.user_id
      AND (focus_sessions.project_id IS NULL OR t.project_id = focus_sessions.project_id));
    UPDATE focus_sessions SET project_id = NULL
    WHERE project_id IS NOT NULL AND NOT EXISTS (
      SELECT 1 FROM projects p WHERE p.id = focus_sessions.project_id AND p.user_id = focus_sessions.user_id);`);
  // Existing databases predate revision tracking. Mark their persisted workspaces
  // as initialized so an old local cache cannot replace them as an empty revision.
  db.exec(`INSERT OR IGNORE INTO data_revisions (user_id, revision)
    SELECT id, 1 FROM users WHERE
      EXISTS (SELECT 1 FROM projects WHERE user_id = users.id) OR
      EXISTS (SELECT 1 FROM tasks WHERE user_id = users.id) OR
      EXISTS (SELECT 1 FROM focus_sessions WHERE user_id = users.id) OR
      EXISTS (SELECT 1 FROM settings WHERE user_id = users.id) OR
      EXISTS (SELECT 1 FROM meta WHERE user_id = users.id)`);
}

// Initialize tables immediately
initDb();

export const teamsDb = {
  list(userId: string): Team[] {
    const teams = db.prepare('SELECT t.* FROM teams t JOIN team_members m ON m.team_id=t.id WHERE m.user_id=? ORDER BY t.created_at').all(userId) as any[];
    if (!teams.length) return [];
    const placeholders = teams.map(() => '?').join(',');
    const ids = teams.map(t => t.id);
    const members = db.prepare(`SELECT m.*,u.name,u.username FROM team_members m JOIN users u ON u.id=m.user_id WHERE m.team_id IN (${placeholders}) ORDER BY m.role DESC,m.joined_at`).all(...ids) as any[];
    const tasks = db.prepare(`SELECT * FROM team_tasks WHERE team_id IN (${placeholders}) ORDER BY done,created_at DESC`).all(...ids) as any[];
    return teams.map(row => ({
      id: row.id, name: row.name, color: row.color, ownerId: row.owner_id, createdAt: row.created_at,
      members: members.filter(m => m.team_id === row.id).map(m => ({ userId: m.user_id, name: m.name, username: m.username, role: m.role, joinedAt: m.joined_at })),
      tasks: tasks.filter(t => t.team_id === row.id).map(t => ({ id: t.id, teamId: t.team_id, title: t.title, done: !!t.done, assigneeId: t.assignee_id || undefined, createdBy: t.created_by ?? undefined, createdAt: t.created_at }))
    }));
  },
  create(team:Team,userId:string) { db.transaction(()=>{db.prepare('INSERT INTO teams(id,name,color,owner_id,created_at) VALUES(?,?,?,?,?)').run(team.id,team.name,team.color,userId,team.createdAt);db.prepare("INSERT INTO team_members(team_id,user_id,role,joined_at) VALUES(?,?,'owner',?)").run(team.id,userId,team.createdAt);})(); },
  addMember(teamId:string,ownerId:string,username:string) { if(!db.prepare('SELECT 1 FROM teams WHERE id=? AND owner_id=?').get(teamId,ownerId)) return 'forbidden'; const u=db.prepare('SELECT id FROM users WHERE lower(username)=lower(?)').get(username.trim()) as any; if(!u)return 'missing';db.prepare("INSERT OR IGNORE INTO team_members(team_id,user_id,role,joined_at) VALUES(?,?,'member',?)").run(teamId,u.id,new Date().toISOString());return 'ok'; },
  addTask(teamId: string, userId: string, task: { id: string; title: string; assigneeId?: string; createdAt: string }) {
    return db.transaction(() => {
      const isMember = (id: string) => !!db.prepare('SELECT 1 FROM team_members WHERE team_id=? AND user_id=?').get(teamId, id);
      if (!isMember(userId)) return 'forbidden';
      if (task.assigneeId && !isMember(task.assigneeId)) return 'invalid_assignee';
      db.prepare('INSERT INTO team_tasks(id,team_id,title,assignee_id,created_by,created_at) VALUES(?,?,?,?,?,?)')
        .run(task.id, teamId, task.title, task.assigneeId ?? null, userId, task.createdAt);
      return 'ok';
    }).immediate();
  },
  toggleTask(teamId:string,taskId:string,userId:string,done:boolean) { if(!db.prepare('SELECT 1 FROM team_members WHERE team_id=? AND user_id=?').get(teamId,userId))return false;return !!db.prepare('UPDATE team_tasks SET done=? WHERE id=? AND team_id=?').run(done?1:0,taskId,teamId).changes; },
  remove(teamId:string,userId:string) { return !!db.prepare('DELETE FROM teams WHERE id=? AND owner_id=?').run(teamId,userId).changes; }
};

// ---------------- Users ----------------
export const usersDb = {
  create(user: User): void {
    const stmt = db.prepare(`
      INSERT INTO users (id, name, username, password_hash, created_at, avatar, password_changed_at, role)
      VALUES (@id, @name, @username, @passwordHash, @createdAt, @avatar, @passwordChangedAt, @role)
    `);
    stmt.run({
      id: user.id,
      name: user.name,
      username: user.username.toLowerCase().trim(),
      role: user.role ?? 'user',
      passwordHash: user.passwordHash,
      createdAt: user.createdAt,
      avatar: user.avatar || null,
      passwordChangedAt: user.passwordChangedAt || null,
    });
  },

  findById(id: string): User | null {
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id) as any;
    if (!row) return null;
    return {
      id: row.id,
      name: row.name,
      username: row.username,
      role: row.role,
      authVersion: row.auth_version,
      passwordHash: row.password_hash,
      createdAt: row.created_at,
      avatar: row.avatar || undefined,
      passwordChangedAt: row.password_changed_at || undefined,
    };
  },

  findByUsername(username: string): User | null {
    const row = db.prepare('SELECT * FROM users WHERE LOWER(username) = LOWER(?)').get(username.trim()) as any;
    if (!row) return null;
    return {
      id: row.id,
      name: row.name,
      username: row.username,
      role: row.role,
      authVersion: row.auth_version,
      passwordHash: row.password_hash,
      createdAt: row.created_at,
      avatar: row.avatar || undefined,
      passwordChangedAt: row.password_changed_at || undefined,
    };
  },

  update(id: string, patch: Partial<Omit<User, 'id' | 'username'>>): User | null {
    const current = usersDb.findById(id);
    if (!current) return null;
    const updated = { ...current, ...patch };
    const stmt = db.prepare(`
      UPDATE users
      SET name = @name, password_hash = @passwordHash, avatar = @avatar, password_changed_at = @passwordChangedAt
      WHERE id = @id
    `);
    stmt.run({
      id,
      name: updated.name,
      passwordHash: updated.passwordHash,
      avatar: updated.avatar || null,
      passwordChangedAt: updated.passwordChangedAt || null,
    });
    return updated;
  },

  upgradePasswordHash(id: string, expected: string, hash: string): User | null {
    const info = db.prepare('UPDATE users SET password_hash = ? WHERE id = ? AND password_hash = ?').run(hash, id, expected);
    return info.changes ? usersDb.findById(id) : null;
  },

  changePassword(id: string, expected: string, hash: string): User | null {
    const info = db.prepare('UPDATE users SET password_hash = ?, password_changed_at = ?, auth_version = auth_version + 1 WHERE id = ? AND password_hash = ?')
      .run(hash, new Date().toISOString(), id, expected);
    return info.changes ? usersDb.findById(id) : null;
  },

  delete(id: string): boolean {
    return db.transaction(() => {
      const teams = db.prepare('SELECT id FROM teams WHERE owner_id = ?').all(id) as { id: string }[];
      for (const team of teams) {
        const successor = db.prepare(`
          SELECT user_id FROM team_members WHERE team_id = ? AND user_id <> ?
          ORDER BY joined_at, user_id LIMIT 1
        `).get(team.id, id) as { user_id: string } | undefined;
        if (!successor) continue;
        db.prepare('UPDATE teams SET owner_id = ? WHERE id = ?').run(successor.user_id, team.id);
        db.prepare("UPDATE team_members SET role = 'owner' WHERE team_id = ? AND user_id = ?").run(team.id, successor.user_id);
      }
      return db.prepare('DELETE FROM users WHERE id = ?').run(id).changes > 0;
    }).immediate();
  },
};

// ---------------- Settings ----------------
export const settingsDb = {
  get(userId: string): Settings {
    const row = db.prepare('SELECT * FROM settings WHERE user_id = ?').get(userId) as any;
    if (!row) return defaultSettings(userId);
    return {
      userId: row.user_id,
      theme: row.theme,
      dailyGoalMin: row.daily_goal_min,
      defaultTaskMin: row.default_task_min,
      timeZone: row.time_zone,
      weekStart: row.week_start,
      autoReplan: Boolean(row.auto_replan),
      deadlineAlerts: Boolean(row.deadline_alerts),
      weeklyDigest: Boolean(row.weekly_digest),
      focusSound: Boolean(row.focus_sound),
    };
  },

  save(settings: Settings): void {
    const stmt = db.prepare(`
      INSERT INTO settings (user_id, theme, daily_goal_min, default_task_min, time_zone, week_start, auto_replan, deadline_alerts, weekly_digest, focus_sound)
      VALUES (@userId, @theme, @dailyGoalMin, @defaultTaskMin, @timeZone, @weekStart, @autoReplan, @deadlineAlerts, @weeklyDigest, @focusSound)
      ON CONFLICT(user_id) DO UPDATE SET
        theme = excluded.theme,
        daily_goal_min = excluded.daily_goal_min,
        default_task_min = excluded.default_task_min,
        time_zone = excluded.time_zone,
        week_start = excluded.week_start,
        auto_replan = excluded.auto_replan,
        deadline_alerts = excluded.deadline_alerts,
        weekly_digest = excluded.weekly_digest,
        focus_sound = excluded.focus_sound
    `);
    stmt.run({
      userId: settings.userId,
      theme: settings.theme,
      dailyGoalMin: settings.dailyGoalMin,
      defaultTaskMin: settings.defaultTaskMin,
      timeZone: settings.timeZone,
      weekStart: settings.weekStart,
      autoReplan: settings.autoReplan ? 1 : 0,
      deadlineAlerts: settings.deadlineAlerts ? 1 : 0,
      weeklyDigest: settings.weeklyDigest ? 1 : 0,
      focusSound: settings.focusSound ? 1 : 0,
    });
  },
};

// ---------------- Meta ----------------
export const metaDb = {
  get(userId: string): Meta {
    const row = db.prepare('SELECT * FROM meta WHERE user_id = ?').get(userId) as any;
    if (!row) return defaultMeta(userId);
    return {
      userId: row.user_id,
      lastAutoReplanAt: row.last_auto_replan_at || undefined,
      shownAlerts: row.shown_alerts ? JSON.parse(row.shown_alerts) : [],
      snoozedAlerts: row.snoozed_alerts ? JSON.parse(row.snoozed_alerts) : {},
      timer: row.timer ? JSON.parse(row.timer) : undefined,
      parking: row.parking ? JSON.parse(row.parking) : [],
      lastReplan: row.last_replan ? JSON.parse(row.last_replan) : undefined,
      onboarded: Boolean(row.onboarded),
      dashboard: row.dashboard ? JSON.parse(row.dashboard) : undefined,
    };
  },

  save(meta: Meta): void {
    const stmt = db.prepare(`
      INSERT INTO meta (user_id, last_auto_replan_at, shown_alerts, snoozed_alerts, timer, parking, last_replan, onboarded, dashboard)
      VALUES (@userId, @lastAutoReplanAt, @shownAlerts, @snoozedAlerts, @timer, @parking, @lastReplan, @onboarded, @dashboard)
      ON CONFLICT(user_id) DO UPDATE SET
        last_auto_replan_at = excluded.last_auto_replan_at,
        shown_alerts = excluded.shown_alerts,
        snoozed_alerts = excluded.snoozed_alerts,
        timer = excluded.timer,
        parking = excluded.parking,
        last_replan = excluded.last_replan,
        onboarded = excluded.onboarded,
        dashboard = COALESCE(excluded.dashboard, meta.dashboard)
    `);
    stmt.run({
      userId: meta.userId,
      lastAutoReplanAt: meta.lastAutoReplanAt || null,
      shownAlerts: JSON.stringify(meta.shownAlerts || []),
      snoozedAlerts: JSON.stringify(meta.snoozedAlerts || {}),
      timer: meta.timer ? JSON.stringify(meta.timer) : null,
      parking: JSON.stringify(meta.parking || []),
      lastReplan: meta.lastReplan ? JSON.stringify(meta.lastReplan) : null,
      onboarded: meta.onboarded ? 1 : 0,
      dashboard: meta.dashboard ? JSON.stringify(meta.dashboard) : null,
    });
  },
};

// ---------------- Projects ----------------
export const projectsDb = {
  getByUser(userId: string): Project[] {
    const rows = db.prepare('SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC').all(userId) as any[];
    return rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      name: r.name,
      color: r.color,
      description: r.description || undefined,
      priority: r.priority,
      dueDate: r.due_date,
      createdAt: r.created_at,
      completedAt: r.completed_at || undefined,
    }));
  },

  save(p: Project): void {
    assertOwner('projects', p.id, p.userId);
    const stmt = db.prepare(`
      INSERT INTO projects (id, user_id, name, color, description, priority, due_date, created_at, completed_at)
      VALUES (@id, @userId, @name, @color, @description, @priority, @dueDate, @createdAt, @completedAt)
      ON CONFLICT(id) DO UPDATE SET
        user_id = excluded.user_id,
        name = excluded.name,
        color = excluded.color,
        description = excluded.description,
        priority = excluded.priority,
        due_date = excluded.due_date,
        completed_at = excluded.completed_at
    `);
    stmt.run({
      id: p.id,
      userId: p.userId,
      name: p.name,
      color: p.color,
      description: p.description || null,
      priority: p.priority,
      dueDate: p.dueDate,
      createdAt: p.createdAt,
      completedAt: p.completedAt || null,
    });
  },

  delete(id: string, userId: string): boolean {
    return db.transaction(() => {
      db.prepare('UPDATE focus_sessions SET task_id = NULL, project_id = NULL WHERE user_id = ? AND (project_id = ? OR task_id IN (SELECT id FROM tasks WHERE project_id = ? AND user_id = ?))').run(userId, id, id, userId);
      const info = db.prepare('DELETE FROM projects WHERE id = ? AND user_id = ?').run(id, userId);
      return info.changes > 0;
    })();
  },
};

// ---------------- Tasks ----------------
export const tasksDb = {
  getByUser(userId: string): Task[] {
    const rows = db.prepare('SELECT * FROM tasks WHERE user_id = ? ORDER BY task_order ASC').all(userId) as any[];
    return rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      projectId: r.project_id,
      section: r.section,
      title: r.title,
      estimateMin: r.estimate_min,
      status: r.status,
      order: r.task_order,
      scheduledFor: r.scheduled_for || undefined,
      dueDate: r.due_date || undefined,
      completedAt: r.completed_at || undefined,
      createdAt: r.created_at,
      replannedFrom: r.replanned_from || undefined,
      subtasks: r.subtasks ? JSON.parse(r.subtasks) : undefined,
    }));
  },

  save(t: Task): void {
    assertOwner('tasks', t.id, t.userId);
    if (!db.prepare('SELECT 1 FROM projects WHERE id = ? AND user_id = ?').get(t.projectId, t.userId)) throw new DataValidationError('Project does not belong to user');
    if (t.subtasks !== undefined && (!Array.isArray(t.subtasks) || t.subtasks.some((s) => !s || typeof s.id !== 'string' || !s.id || typeof s.title !== 'string' || !s.title.trim() || typeof s.done !== 'boolean') || new Set(t.subtasks.map((s) => s.id)).size !== t.subtasks.length)) throw new DataValidationError('Invalid subtasks');
    if (t.dueDate !== undefined && (typeof t.dueDate !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(t.dueDate) || Number.isNaN(Date.parse(`${t.dueDate}T00:00:00Z`)) || new Date(`${t.dueDate}T00:00:00Z`).toISOString().slice(0, 10) !== t.dueDate)) throw new DataValidationError('Invalid task deadline');
    const stmt = db.prepare(`
      INSERT INTO tasks (id, user_id, project_id, section, title, estimate_min, status, task_order, scheduled_for, completed_at, created_at, replanned_from, subtasks, due_date)
      VALUES (@id, @userId, @projectId, @section, @title, @estimateMin, @status, @order, @scheduledFor, @completedAt, @createdAt, @replannedFrom, @subtasks, @dueDate)
      ON CONFLICT(id) DO UPDATE SET
        user_id = excluded.user_id,
        project_id = excluded.project_id,
        section = excluded.section,
        title = excluded.title,
        estimate_min = excluded.estimate_min,
        status = excluded.status,
        task_order = excluded.task_order,
        scheduled_for = excluded.scheduled_for,
        completed_at = excluded.completed_at,
        replanned_from = excluded.replanned_from,
        subtasks = excluded.subtasks,
        due_date = excluded.due_date
    `);
    stmt.run({
      id: t.id,
      userId: t.userId,
      projectId: t.projectId,
      section: t.section,
      title: t.title,
      estimateMin: t.estimateMin,
      status: t.status,
      order: t.order,
      scheduledFor: t.scheduledFor || null,
      completedAt: t.completedAt || null,
      createdAt: t.createdAt,
      replannedFrom: t.replannedFrom || null,
      subtasks: t.subtasks === undefined ? null : JSON.stringify(t.subtasks),
      dueDate: t.dueDate || null,
    });
  },

  delete(id: string, userId: string): boolean {
    return db.transaction(() => {
      db.prepare('UPDATE focus_sessions SET task_id = NULL WHERE user_id = ? AND task_id = ?').run(userId, id);
      const info = db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(id, userId);
      return info.changes > 0;
    })();
  },
};

// ---------------- Focus Sessions ----------------
export const sessionsDb = {
  getByUser(userId: string): FocusSession[] {
    const rows = db.prepare('SELECT * FROM focus_sessions WHERE user_id = ? ORDER BY started_at DESC').all(userId) as any[];
    return rows.map((r) => ({
      id: r.id,
      userId: r.user_id,
      taskId: r.task_id || undefined,
      projectId: r.project_id || undefined,
      startedAt: r.started_at,
      endedAt: r.ended_at,
      minutes: r.minutes,
      completedTask: Boolean(r.completed_task),
    }));
  },

  save(s: FocusSession): void {
    db.transaction(() => {
      assertOwner('focus_sessions', s.id, s.userId);
      if ((s.taskId !== undefined && (typeof s.taskId !== 'string' || !s.taskId)) || (s.projectId !== undefined && (typeof s.projectId !== 'string' || !s.projectId))) throw new DataValidationError('Invalid session references');
      if (s.projectId && !db.prepare('SELECT 1 FROM projects WHERE id = ? AND user_id = ?').get(s.projectId, s.userId)) throw new DataValidationError('Session project does not belong to user');
      if (s.taskId) {
        const task = db.prepare('SELECT project_id FROM tasks WHERE id = ? AND user_id = ?').get(s.taskId, s.userId) as { project_id: string } | undefined;
        if (!task || (s.projectId && task.project_id !== s.projectId)) throw new DataValidationError('Invalid session task or project');
      }
      const stmt = db.prepare(`
        INSERT INTO focus_sessions (id, user_id, task_id, project_id, started_at, ended_at, minutes, completed_task)
        VALUES (@id, @userId, @taskId, @projectId, @startedAt, @endedAt, @minutes, @completedTask)
        ON CONFLICT(id) DO UPDATE SET
          user_id = excluded.user_id,
          task_id = excluded.task_id,
          project_id = excluded.project_id,
          started_at = excluded.started_at,
          ended_at = excluded.ended_at,
          minutes = excluded.minutes,
          completed_task = excluded.completed_task
      `);
      stmt.run({
        id: s.id,
        userId: s.userId,
        taskId: s.taskId || null,
        projectId: s.projectId || null,
        startedAt: s.startedAt,
        endedAt: s.endedAt,
        minutes: s.minutes,
        completedTask: s.completedTask ? 1 : 0,
      });
    })();
  },

  delete(id: string, userId: string): boolean {
    const info = db.prepare('DELETE FROM focus_sessions WHERE id = ? AND user_id = ?').run(id, userId);
    return info.changes > 0;
  },
};

// ---------------- Bulk AppData Sync ----------------
function assertOwner(table: 'projects' | 'tasks' | 'focus_sessions', id: string, userId: string): void {
  const row = db.prepare(`SELECT user_id FROM ${table} WHERE id = ?`).get(id) as { user_id: string } | undefined;
  if (row && row.user_id !== userId) throw new DataValidationError('Record belongs to another user');
}

export function getDataRevision(userId: string): number {
  const row = db.prepare('SELECT revision FROM data_revisions WHERE user_id = ?').get(userId) as { revision: number } | undefined;
  return row?.revision ?? 0;
}

export function syncAppData(userId: string, data: AppData, revision: number): number | null {
  return db.transaction(() => {
    if (getDataRevision(userId) !== revision) return null;
    saveAppData(userId, data);
    return getDataRevision(userId);
  })();
}

export function getAppData(userId: string): AppData {
  return {
    projects: projectsDb.getByUser(userId),
    tasks: tasksDb.getByUser(userId),
    sessions: sessionsDb.getByUser(userId),
    settings: settingsDb.get(userId),
    meta: metaDb.get(userId),
  };
}

export function saveAppData(userId: string, data: AppData): void {
  const syncTx = db.transaction(() => {
    // Save settings and meta
    settingsDb.save({ ...defaultSettings(userId), ...data.settings, userId });
    metaDb.save({ ...defaultMeta(userId), ...data.meta, userId });

    // Sync projects: remove old projects not in data, upsert existing/new
    const projectIds = new Set(data.projects.map((p) => p.id));
    const currentProjects = projectsDb.getByUser(userId);
    for (const cp of currentProjects) {
      if (!projectIds.has(cp.id)) {
        projectsDb.delete(cp.id, userId);
      }
    }
    for (const p of data.projects) {
      projectsDb.save({ ...p, userId });
    }

    // Sync tasks: remove old tasks not in data, upsert existing/new
    const taskIds = new Set(data.tasks.map((t) => t.id));
    const currentTasks = tasksDb.getByUser(userId);
    for (const ct of currentTasks) {
      if (!taskIds.has(ct.id)) {
        tasksDb.delete(ct.id, userId);
      }
    }
    for (const t of data.tasks) {
      tasksDb.save({ ...t, userId });
    }

    // Sync sessions: remove old sessions not in data, upsert existing/new
    const sessionIds = new Set(data.sessions.map((s) => s.id));
    const currentSessions = sessionsDb.getByUser(userId);
    for (const cs of currentSessions) {
      if (!sessionIds.has(cs.id)) {
        sessionsDb.delete(cs.id, userId);
      }
    }
    for (const s of data.sessions) {
      sessionsDb.save({ ...s, userId });
    }
  });

  syncTx();
}

export function getAdminUsers(page: number, search: string, pageSize = 25) {
  return db.transaction(() => {
    const filter = 'instr(lower(u.username), lower(@search)) > 0 OR instr(lower(u.name), lower(@search)) > 0';
    const { total } = db.prepare(`SELECT COUNT(*) AS total FROM users u WHERE ${filter}`).get({ search }) as { total: number };
    const users = db.prepare(`SELECT u.id, u.name, u.username, u.role, u.created_at AS createdAt,
      (SELECT COUNT(*) FROM projects p WHERE p.user_id = u.id) AS projects,
      (SELECT COUNT(*) FROM tasks t WHERE t.user_id = u.id) AS tasks,
      (SELECT COUNT(*) FROM tasks t WHERE t.user_id = u.id AND t.status = 'done') AS completedTasks,
      (SELECT COUNT(*) FROM focus_sessions s WHERE s.user_id = u.id) AS sessions,
      (SELECT COALESCE(SUM(minutes), 0) FROM focus_sessions s WHERE s.user_id = u.id) AS focusMinutes
      FROM users u WHERE ${filter}
      ORDER BY u.created_at DESC, u.id ASC LIMIT @limit OFFSET @offset`).all({ search, limit: pageSize, offset: (page - 1) * pageSize });
    const summary = db.prepare(`SELECT
      (SELECT COUNT(*) FROM users) AS users,
      (SELECT COUNT(*) FROM projects) AS projects,
      (SELECT COUNT(*) FROM tasks) AS tasks,
      (SELECT COUNT(*) FROM focus_sessions) AS sessions,
      (SELECT COALESCE(SUM(minutes), 0) FROM focus_sessions) AS focusMinutes`).get();
    return { users, page, pageSize, total, totalPages: Math.max(1, Math.ceil(total / pageSize)), summary };
  })();
}

export function getAppDataSnapshot(userId: string) {
  return db.transaction(() => ({ data: getAppData(userId), revision: getDataRevision(userId) }))();
}

export function createAdminAccount(user: User): void {
  db.transaction(() => { usersDb.create(user); metaDb.save({ ...defaultMeta(user.id), onboarded: true }); })();
}

export async function closeDatabase(): Promise<void> { db.close(); }

export function checkDatabase() { db.prepare('SELECT 1').get(); }

ALTER TABLE meta ADD COLUMN dashboard JSONB;

ALTER TABLE team_tasks DROP CONSTRAINT team_tasks_created_by_fkey;
ALTER TABLE team_tasks ALTER COLUMN created_by DROP NOT NULL;
ALTER TABLE team_tasks ADD CONSTRAINT team_tasks_created_by_fkey
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;

UPDATE team_tasks AS task
SET assignee_id = NULL
WHERE assignee_id IS NOT NULL AND NOT EXISTS (
  SELECT 1 FROM team_members AS member
  WHERE member.team_id = task.team_id AND member.user_id = task.assignee_id
);

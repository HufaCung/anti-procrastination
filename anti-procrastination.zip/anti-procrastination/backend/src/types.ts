export type ID = string;
export type Priority = 'low' | 'medium' | 'high';
export type TaskStatus = 'todo' | 'in_progress' | 'done';
export type Risk = 'on_track' | 'at_risk' | 'overdue' | 'done';
export type Theme = 'light' | 'dark';

export interface User {
  id: ID;
  name: string;
  username: string;
  role?: 'user' | 'admin';
  authVersion?: number;
  passwordHash: string;
  createdAt: string;
  avatar?: string;
  passwordChangedAt?: string;
}

export type SafeUser = Omit<User, 'passwordHash' | 'authVersion'>;

export interface Settings {
  userId: ID;
  theme: Theme;
  dailyGoalMin: number;
  defaultTaskMin: 10 | 15;
  timeZone: string;
  weekStart: 'mon' | 'sun';
  autoReplan: boolean;
  deadlineAlerts: boolean;
  weeklyDigest: boolean;
  focusSound: boolean;
}

export interface Project {
  id: ID;
  userId: ID;
  name: string;
  color: string;
  description?: string;
  priority: Priority;
  dueDate: string;
  createdAt: string;
  completedAt?: string;
}

export interface Task {
  id: ID;
  userId: ID;
  projectId: ID;
  section: string;
  title: string;
  estimateMin: number;
  status: TaskStatus;
  order: number;
  dueDate?: string; // Optional task deadline (YYYY-MM-DD)
  scheduledFor?: string;
  completedAt?: string;
  createdAt: string;
  replannedFrom?: string;
  subtasks?: Subtask[];
}

export interface Subtask {
  id: ID;
  title: string;
  done: boolean;
}

export interface FocusSession {
  id: ID;
  userId: ID;
  taskId?: ID;
  projectId?: ID;
  startedAt: string;
  endedAt: string;
  minutes: number;
  completedTask: boolean;
}

export interface ActiveTimer {
  taskId?: ID;
  lengthMs: number;
  endsAt?: number;
  remainingMs: number;
  running: boolean;
  firstStartedAt?: string;
}

export interface ParkingNote {
  id: ID;
  text: string;
  createdAt: string;
}

export interface ReplanUndo {
  at: string;
  entries: { taskId: ID; scheduledFor?: string; replannedFrom?: string }[];
}

export interface DashboardMetadata {
  projects: Record<ID, { status: 'On Track' | 'At Risk' | 'Completed'; weeklyTargetMinutes: number }>;
  tasks: Record<ID, { scheduledTime: string; loggedMinutes: number; priority: Priority }>;
  sessions: Record<ID, { mode: 'pomodoro' | 'deep' | 'short_break' | 'long_break' | 'custom'; date: string }>;
}

export interface Meta {
  dashboard?: DashboardMetadata;
  userId: ID;
  lastAutoReplanAt?: string;
  shownAlerts: string[];
  snoozedAlerts: Record<ID, string>;
  timer?: ActiveTimer;
  parking: ParkingNote[];
  lastReplan?: ReplanUndo;
  onboarded?: boolean;
}

export interface AppData {
  projects: Project[];
  tasks: Task[];
  sessions: FocusSession[];
  settings: Settings;
  meta: Meta;
}

export interface TeamMember { userId: ID; name: string; username: string; role: 'owner' | 'member'; joinedAt: string; }
export interface TeamTask { id: ID; teamId: ID; title: string; done: boolean; assigneeId?: ID; createdBy?: ID; createdAt: string; }
export interface Team { id: ID; name: string; color: string; ownerId: ID; createdAt: string; members: TeamMember[]; tasks: TeamTask[]; }

import type { RequestHandler } from 'express';

export function authRateLimit(limit: number, windowMs = 60_000): RequestHandler {
  const requests = new Map<string, number>();
  let end = Date.now() + windowMs;
  return (req, res, next) => {
    const now = Date.now();
    if (now >= end) {
      requests.clear();
      end = now + windowMs;
    }
    const ip = req.ip ?? req.socket.remoteAddress ?? 'unknown';
    const count = requests.get(ip) ?? 0;
    if (count >= limit || (!count && requests.size >= 10_000)) {
      res.set('Retry-After', String(Math.max(1, Math.ceil((end - now) / 1000))));
      res.status(429).json({ error: 'Too many authentication attempts. Try again later.' });
      return;
    }
    requests.set(ip, count + 1);
    next();
  };
}

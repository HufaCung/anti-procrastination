# TinyDo

TinyDo combines a personal dashboard, projects, calendar, focus sessions and shared team tasks.

## Local development

Use Node 22.12+ on the 22.x line or Node 24+. Run `npm ci` in the root. In two terminals, run `npm run dev:backend` and `npm run dev:frontend`. Open the URL printed by Vite. The Vite proxy forwards `/api` to port 3001. The backend defaults to a local SQLite database under `backend/data`.

Create a user on the sign-in screen. New accounts start empty. If TinyDo finds an older browser workspace on the same origin, sign in to the intended account and choose **Import browser workspace**. Personal projects, tasks and focus history are copied into that account. Shared memberships and task assignments are managed separately under **Teams**.

The workspace autosaves. If it detects a concurrent update, load the latest server copy before choosing which version to keep. Replacing the server with a local copy can remove changes from another tab. Unsaved drafts survive reloads within their tab. Keep the tab open until **Saved** appears.

## Build and test

```sh
npm ci
npm run build
npm test
npm run test:postgres
```

## Production configuration

Set backend environment variables in the service environment or in `backend/.env` for a local start. See `backend/.env.example`. Set `NODE_ENV=production` and a strong `JWT_SECRET`, then run `npm start` from the root. Express serves the built frontend and the API on one origin. Set `DATABASE_URL` and `REQUIRE_DATABASE_URL=true` for PostgreSQL. Schema migrations run at startup, or can be applied explicitly with `npm run db:migrate` after building. Back up an existing database before deploying a schema upgrade.

Use `GET /api/health` for process liveness and `GET /api/ready` for database readiness. Login and signup have per-process IP limits. If the service sits behind a fixed trusted proxy chain, configure `TRUST_PROXY_HOPS` to match it.

When a team owner deletes their account, ownership passes to the longest-standing remaining member, with the user ID breaking ties. A team with no remaining members is deleted. Shared tasks in retained teams survive account deletion and assignments to the deleted user are cleared.

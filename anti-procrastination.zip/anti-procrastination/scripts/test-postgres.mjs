import EmbeddedPostgres from 'embedded-postgres';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { mkdtemp, rm } from 'node:fs/promises';
import { createServer } from 'node:net';
import { join, resolve, basename, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

const port = await new Promise((resolve, reject) => {
  const server = createServer().once('error', reject);
  server.listen(0, '127.0.0.1', () => {
    const port = server.address().port;
    server.close(error => error ? reject(error) : resolve(port));
  });
});
const directory = await mkdtemp(join(tmpdir(), 'tinydo-local-pg-'));
const password = randomUUID();
const databaseDir = join(directory, 'data');
const pgCtl = process.platform === 'win32' ? (await import('@embedded-postgres/windows-x64')).pg_ctl : undefined;
const control = args => new Promise((resolve, reject) => {
  spawn(pgCtl, ['-D', databaseDir, '-w', '-t', '25', ...args], { windowsHide: true, stdio: 'ignore' })
    .once('error', reject).once('exit', code => code === 0 ? resolve() : reject(new Error('pg_ctl exited with code ' + code)));
});
const cluster = new EmbeddedPostgres({
  databaseDir, user: 'tinydo_test', password, port,
  persistent: true, authMethod: 'scram-sha-256',
  initdbFlags: ['--encoding=UTF8', '--locale=C'], postgresFlags: ['-h', '127.0.0.1'],
  onLog: () => {}, onError: console.error,
});

let started = false;
try {
  await cluster.initialise();
  if (pgCtl) await control(['-l', join(directory, 'postgres.log'), '-o', '-h 127.0.0.1 -p ' + port, 'start']);
  else await cluster.start();
  started = true;
  const testPath = fileURLToPath(new URL('../node_modules/vitest/vitest.mjs', import.meta.url));
  const cwd = fileURLToPath(new URL('../backend/', import.meta.url));
  process.exitCode = await new Promise((resolve, reject) => {
    spawn(process.execPath, [testPath, 'run', 'src/dashboard-teams.test.ts'], {
      cwd, windowsHide: true, stdio: 'inherit',
      env: { ...process.env, TINYDO_TEST_DATABASE_URL: 'postgresql://tinydo_test:' + password + '@127.0.0.1:' + port + '/postgres' },
    }).once('error', reject).once('exit', code => resolve(code ?? 1));
  });
} finally {
  try {
    if (started && pgCtl) await control(['-m', 'fast', 'stop']);
    else if (started) await cluster.stop();
  }
  finally {
    const target = resolve(directory);
    if (dirname(target) !== resolve(tmpdir()) || !basename(target).startsWith('tinydo-local-pg-')) throw new Error('Unexpected PostgreSQL test path');
    await rm(target, { recursive: true, force: true, maxRetries: 10, retryDelay: 200 });
  }
}
